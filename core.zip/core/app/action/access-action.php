<br>
<?php


if (isset($_GET["opt"]) && $_GET["opt"] == "login") {


	if (!isset($_SESSION['user_id'])) {
		$val_user = htmlentities($_POST['usuario']);
		$val_pass = htmlentities($_POST['contra']);
		//$val_pass = sha1(md5($val_pass));

		//sha1(md5($val_pass));


		$base = new Database();
		$con = $base->connect();

		$sentencia = "select * from seguimiento_egresados2.usuarios where Nombre_Usuario=\"" . $val_user . "\"  and Status=1 and Password=\"" . $val_pass . "\"";
		try{
		$query = $con->query($sentencia);

		}catch (Exception){
			Core::redir("./?view=Error");
		exit;
		}
		$encontre = false;

		$username = "";
		while ($r = $query->fetch_array()) {
			$encontre = true;
			$userid  = $r['ID_usuario'];
			$username = $r['Nombre_Usuario'];
		}



		if ($encontre == true) {
			$_SESSION['user_id'] = $userid;

			print "Cargando ... $username";


			Core::addToastr("info", "Bienvenido $username");
			Core::redir("./?view=index");
		} else {
			Core::addToastr("warning", "DATOS INCORRECTOS");

			Core::redir("./");
		}
	} else {
		Core::redir("./?view=graduados");
	}
} else if (isset($_GET["opt"]) && $_GET["opt"] == "logout") {
	unset($_SESSION);
	session_destroy();

	Core::redir("./");
}





?>