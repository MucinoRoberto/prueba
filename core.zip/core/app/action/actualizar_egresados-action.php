<?php

$egresado = new Egresados();
$alumno=new Inscritos();


$matricula = $_POST['Matricula'];
$Nombre = $_POST['Nombre'];
$ApellidoP = $_POST['ApellidoP'];
$ApellidoM = $_POST['ApellidoM'];
$Carrera = $_POST['Carrera'];
$Area = $_POST['area'];
$Periodo = $_POST['periodo'];
$Ingreso = $_POST['Ingreso'];
$Egreso = $_POST['Egreso'];
$Trabajo = $_POST['Trabajo'];
$Movilidad = $_POST['movilidad'];
$DOB = $_POST['dob'];

$Director1= $_POST['director1'] ?? '';
$Director2= $_POST['director2'] ?? '';


$Telefono1 = $_POST['Telefono1'] ?? '';
$Telefono2 = $_POST['Telefono2'] ?? '';
$TelefonoNuevo1 = $_POST['TelefonoNuevo1'] ?? '';
$TelefonoNuevo2 = $_POST['TelefonoNuevo2'] ?? '';
$TelefonoViejo1=$_POST['telefonoviejo1'] ?? '';
$TelefonoViejo2=$_POST['telefonoviejo2'] ?? '';
$IdTelefonoViejo1=$_POST['idtelefonoviejo1'] ?? '';
$IdTelefonoViejo2=$_POST['idtelefonoviejo2'] ?? '';

$Correo1 = $_POST['Correo1'] ?? '';
$Correo2 = $_POST['Correo2'] ?? '';
$CorreoViejo1 = $_POST['correoviejo1'] ?? '';
$CorreoViejo2 = $_POST['correoviejo2'] ?? '';
$IdCorreoViejo1 = $_POST['idcorreoviejo1'] ?? '';
$IdCorreoViejo2 = $_POST['idcorreoviejo2'] ?? '';
$CorreoNuevo1 = $_POST['CorreoNuevo1'] ?? '';
$CorreoNuevo2 = $_POST['CorreoNuevo2'] ?? '';

$datos_egresado=$egresado->getEgresado($matricula);
$Director=$egresado->getDirector($matricula);
$Codirector=$egresado->getCodirector($matricula);


if($datos_egresado->Dob!=$DOB){
    $actualizar=$alumno->UpdateDob($matricula,$DOB);
    if($actualizar!=null)
    Core::addToastr('success', "Fecha de nacimiento actualizada correctamente");
    else
    Core::addToastr('warning', "Fecha de nacimiento no actualizada ");

}

if ($datos_egresado->egreso != $Egreso) {
    $actualizar=$egresado->UpdateEgreso($matricula, $Egreso, $Periodo);
    if($actualizar!=null)
    Core::addToastr('success', "Fecha de egreso actualizada correctamente");
    else
    Core::addToastr('warning', "Fecha de egreso no actualizada ");
}

if ($datos_egresado->ingreso != $Ingreso) {
    $actualizar=$alumno->UpdateIngreso($Ingreso, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Fecha de ingreso actualizada correctamente");
    else
    Core::addToastr('warning', "Fecha de ingreso no actualizada ");
}

if ($datos_egresado->Nombre != $Nombre) {
    $actualizar=$alumno->UpdateNombre($Nombre, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Nombre actualizado correctamente");
    else
    Core::addToastr('warning', "Nombre no actualizado");
}

if ($datos_egresado->Apellido_p != $ApellidoP) {
    $actualizar=$alumno->UpdateApellidoP($ApellidoP, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Apellido paterno actualizado correctamente");
    else
    Core::addToastr('warning', "Apellido paterno no actualizado");
}

if ($datos_egresado->Apellido_M != $ApellidoM) {
    $actualizar=$alumno->UpdateApellidoM($ApellidoM, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Apellido materno actualizado correctamente");
    else
    Core::addToastr('warning', "Apellido materno no actualizado");
}

if ($datos_egresado->Periodo != $Periodo) {
    $actualizar=$egresado->UpdatePeriodo($matricula, $Periodo);
    if($actualizar!=null)
    Core::addToastr('success', "Periodo actualizado correctamente");
    else
    Core::addToastr('warning', "Periodo no actualizado");
}

if ($datos_egresado->Id_movilidad != $Movilidad) {
    $actualizar=$egresado->UpdateMovilidad($matricula, $Movilidad);
    if($actualizar!=null)
    Core::addToastr('success', "Movilidad actualizada correctamente");
    else
    Core::addToastr('warning', "Movilidad no actualizado");
}

if ($datos_egresado->Area != $Area) {
    $actualizar=$egresado->UpdateArea($matricula, $Area);
    if($actualizar!=null)
    Core::addToastr('success', "Área de desarrollo actualizada correctamente");
    else
    Core::addToastr('warning', "Área de desarrollo no actualizado");
}

if ($datos_egresado->Primer_trabajo != $Trabajo) {
    $actualizar=$egresado->UpdateTrabajo($matricula, $Trabajo);
    if($actualizar!=null)
    Core::addToastr('success', "Primer trabajo actualizado correctamente");
    else
    Core::addToastr('warning', "Primer trabajo no actualizado");
}

if ($datos_egresado->Carrera_fk != $Carrera) {
    $actualizar=$alumno->UpdateCarrera($matricula, $Carrera);
    if($actualizar!=null)
    Core::addToastr('success', "Carrera actualizada correctamente");
    else
    Core::addToastr('warning', "Carrera no actualizada ");
}



if(!empty($Director1) && $Director1 != $Director->Director_fk ){
    $actualizar=$egresado->UpdateDirector($Director1,$matricula,1);
    if($actualizar!=null)
    Core::addToastr('success', $Director1);
    else
    Core::addToastr('warning', "Director no actualizado");
}

if(!empty($Director2)&& $Codirector != $Director2->Director_fk){
    $actualizar=$egresado->UpdateDirector($Director2,$matricula,2);
    if($actualizar!=null)
    Core::addToastr('success', "Codirector actualizado correctamente");
    else
    Core::addToastr('warning', "Codirector no actualizado");

}


if (!empty($Telefono1) && $Telefono1 !== $TelefonoViejo1){
    $actualizar=$egresado->UpdateTelefono($Telefono1,$IdTelefonoViejo1);
    if($actualizar!=null)
    Core::addToastr('success', "Telefono actualizado correctamente");
    else
        Core::addToastr('warning', "Telefono no actualizado");
}

if (!empty($Telefono2) && $Telefono2 !== $TelefonoViejo2){
    $actualizar=$egresado->UpdateTelefono($Telefono2,$IdTelefonoViejo2);
    if($actualizar!=null)
        Core::addToastr('success', "Telefono actualizado correctamente");
    else
        Core::addToastr('warning', "Telefono no actualizado");
}

if(!empty($TelefonoNuevo1) && (empty($Telefono1) && empty($Telefono2) )){
    $actualizar=$egresado->setTelefono($matricula,$TelefonoNuevo1);
    if($actualizar!=null)
    Core::addToastr('success', "Telefono agregado correctamente");
    else
    Core::addToastr('warning', "Telefono no agregado");
}

if(!empty($TelefonoNuevo2) && (empty($Telefono2) )){
    $actualizar=$egresado->setTelefono($matricula,$TelefonoNuevo2);
    if($actualizar!=null)
    Core::addToastr('success', "Telefono agregado correctamente");
    else
    Core::addToastr('warning', "Telefono no agregado");
}


if (!empty($Telefono1) && !empty($TelefonoNuevo1)){
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Telefono2) && !empty($TelefonoNuevo2) ){
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Telefono2) && !empty($TelefonoNuevo1) ){
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($TelefonoViejo1) && empty($Telefono1)){
    $actualizar=$egresado->DeleteTelefono($IdTelefonoViejo1);
    if($actualizar!=null)
    Core::addToastr('success', "Telefono eliminado correctamente");
    else
    Core::addToastr('warning', "Telefono no eliminado");
}

if (!empty($TelefonoViejo2) && empty($Telefono2)){
    $actualizar=$egresado->DeleteTelefono($IdTelefonoViejo2);
    if($actualizar!=null)
    Core::addToastr('success', "Telefono eliminado correctamente");
    else
    Core::addToastr('warning', "Telefono no eliminado ");
}




if (!empty($Correo1) && $Correo1 !== $CorreoViejo1) {
    $actualizar=$egresado->UpdateCorreo($Correo1,$IdCorreoViejo1);
    if($actualizar!=null)
    Core::addToastr('success', "Correo actualizado correctamente");
    else
    Core::addToastr('warning', "Correno no actualizado ");
}

if (!empty($Correo2) && $Correo2 !== $CorreoViejo2) {
    $actualizar=$egresado->UpdateCorreo($Correo2, $IdCorreoViejo2);
    if($actualizar!=null)
    Core::addToastr('success', "Correo actualizado correctamente");
    else
    Core::addToastr('warning', "Correno no actualizado");
}

if (!empty($Correo1) && !empty($CorreoNuevo1)) {
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Correo2) && !empty($CorreoNuevo2)) {
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Correo2) && !empty($CorreoNuevo1)) {
    Core::addToastr('warning', "Error en los datos");
}

if (empty($Correo1) && !empty($CorreoViejo1)) {
    $actualizar=$egresado->DeleteCorreo( $IdCorreoViejo1);
    if($actualizar!=null)
    Core::addToastr('success', "Correo eliminado correctamente");
    else
    Core::addToastr('warning', "Correno no eliminado");
}

if (empty($Correo2) && !empty($CorreoViejo2)) {
    $actualizar=$egresado->DeleteCorreo($IdCorreoViejo2);
    if($actualizar!=null)
    Core::addToastr('success', "Correo eliminado correctamente");
    else
    Core::addToastr('warning', "Correno no eliminado");
}

if (!empty($CorreoNuevo1) && empty($Correo1) && empty($Correo2)) {
    $actualizar=$egresado->setCorreo($matricula, $CorreoNuevo1);
    if($actualizar!=null)
    Core::addToastr('success', "Correo agregado correctamente");
    else
    Core::addToastr('warning', "Correno no agregado");
}

if (!empty($CorreoNuevo2) && empty($Correo2)) {
    $actualizar=$egresado->setCorreo($matricula, $CorreoNuevo2);
    if($actualizar!=null)
    Core::addToastr('success', "Correo agregado correctamente");
    else
    Core::addToastr('warning', "Correno no agregado");
}




?>

<form id="detalles" action="./?view=editar_egresado&" method="post" >     
    <input type="hidden" name="opt" value="detail">
    <input type="hidden" name="matricula" value="<?php echo $matricula ?>">    
</form>

<script>

    window.onload = function() {
        document.getElementById('detalles').submit(); 
    };

</script>