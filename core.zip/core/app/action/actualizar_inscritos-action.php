<?php

$egresado = new Egresados();
$alumno=new Inscritos();

$matricula = $_POST['Matricula'];
$Nombre = $_POST['Nombre'];
$ApellidoP = $_POST['ApellidoP'];
$ApellidoM = $_POST['ApellidoM'];
$Carrera = $_POST['Carrera'];
$Ingreso = $_POST['Ingreso'];
$DOB = $_POST['dob'];

$datos_egresado=$alumno->getAlumno($matricula);
$datos_egresado2=$alumno->getAlumno2($matricula);

if($datos_egresado->Dob!=$DOB){
    $actualizar=$alumno->UpdateDob($matricula,$DOB);
    if($actualizar!=null)
    Core::addToastr('success', "Fecha de nacimiento actualizada correctamente");
    else
    Core::addToastr('warning', "Fecha de nacimiento no actualizada ");

}


if ($datos_egresado2->fecha != $Ingreso) {
    $actualizar=$alumno->UpdateIngreso($Ingreso, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Fecha de ingreso actualizada correctamente");
    else
    Core::addToastr('warning', "Fecha de ingreso no actualizada ");
}

if ($datos_egresado->Nombre != $Nombre) {
    $actualizar=$alumno->UpdateNombre($Nombre, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Nombre actualizado correctamente");
    else
    Core::addToastr('warning', "Nombre no actualizado");
}

if ($datos_egresado->Apellido_p != $ApellidoP) {
    $actualizar=$alumno->UpdateApellidoP($ApellidoP, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Apellido paterno actualizado correctamente");
    else
    Core::addToastr('warning', "Apellido paterno no actualizado");
}

if ($datos_egresado->Apellido_M != $ApellidoM) {
    $actualizar=$alumno->UpdateApellidoM($ApellidoM, $matricula);
    if($actualizar!=null)
    Core::addToastr('success', "Apellido materno actualizado correctamente");
    else
    Core::addToastr('warning', "Apellido materno no actualizado");
}

if ($datos_egresado->Carrera_fk != $Carrera) {
    $actualizar=$alumno->UpdateCarrera($matricula, $Carrera);
    if($actualizar!=null)
    Core::addToastr('success', "Carrera actualizada correctamente");
    else
    Core::addToastr('warning', "Carrera no actualizada ");
}

core::redir("?view=inscritos");
exit;
?>