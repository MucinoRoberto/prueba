<?php

$director=new Directores();
$id=$_GET['id'];
$Nombre=$_POST['Nombre'];
$ApellidoP=$_POST['ApellidoP'];
$ApellidoM=$_POST['ApellidoM'];
$Adscripcion=$_POST['Adscripcion'];
$Interno=$_POST['Interno'];

$dirInterno=$director->getInterno($id);

if ($Interno==0){
    if($Adscripcion==0 ){
        Core::addToastr('warning', "Agrega la adscripcion");
        
        
    } else if(empty($Adscripcion)){
        Core::addToastr('warning', "Hubo un error con los datos");
       
        
    }else{
        $Externo=$director->UpdateInternoAExterno($id,$Adscripcion);
        if($Externo==null){
            Core::addToastr('warning', "Hubo un error al actualizar la adscripcion");
       
            
        }else{
            Core::addToastr('success',"Adscripción actualizada correctamente");
            
        }
    }

}

if ($dirInterno->Nombre!=$Nombre){
    $actualizarNombre=$director->UpdateNombre($id,$Nombre);
    if($actualizarNombre==null){
        Core::addToastr('warning', "Hubo un error al actualizar el nombre");
       
    }else{
        Core::addToastr('success',"Nombre actualizada correctamente");
    }
}

if ($dirInterno->Apellido_p!=$ApellidoP){
    $actualizarApellidop=$director->UpdateApellidoP($id,$ApellidoP);
    if($actualizarApellidop==null){
        Core::addToastr('warning', "Hubo un error al actualizar el apellido paterno");
       
    }else{
        Core::addToastr('success',"Apellido paterno actualizada correctamente");
    }
}
    
if ($dirInterno->Apellido_M!=$ApellidoM){
    $actualizarApellidoM=$director->UpdateApellidoM($id,$ApellidoM);
    if($actualizarApellidoM==null){
        Core::addToastr('warning', "Hubo un error al actualizar el apeliido materno");
       
    }else{
        Core::addToastr('success',"Apellido materno actualizada correctamente");
    }
}

    

?>
<form id="directores" action="./?view=editar_director&" method="post">
<?php if($Interno==0 && !empty($Adscripcion)){
    ?>
<input type="hidden" name="opt" value="externo">
<?php }else {
    ?>
    <input type="hidden" name="opt" value="interno">
    <?php 
}?>
<input type="hidden" name="id" value="<?php echo $id; ?>"> 
</form>

<script>

window.onload = function() {
    document.getElementById('directores').submit(); 
};

</script>