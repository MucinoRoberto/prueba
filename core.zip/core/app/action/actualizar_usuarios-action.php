

<form id="propio" action="./?view=editar_usuario&" method="post" >     
        <input type="hidden" name="opt" value="propio">
        <input type="hidden" name="id" value="<?php echo $_SESSION["user_id"]?>">
</form>

<?php

$editar=new Usuarios();


if(isset($_SESSION["user_id"])){
    $user=$editar->getUsuario($_SESSION["user_id"]);
    if(isset($_POST["opt"]) && $_POST["opt"] == "propio"){
        $nombre=$_POST['Nombre'];
        $apellidop=$_POST['ApellidoP'];
        $apellidom=$_POST['ApellidoM'];
        $user=$_POST['user'];
        $password=$_POST['contra'] ?? '';
        $newpassword=$_POST['contranueva'] ?? '';
        $usuario=$editar->getUsuario($_SESSION["user_id"]);
        
        if(!empty($password)){
           
            $verificarUsuario=$editar->VerificarUsuario($usuario->Nombre_Usuario,$password);
            if($verificarUsuario->count==1){
                if(empty($newpassword)){
                    Core::addToastr('warning', "Ingresa una contraseña nueva");
                    if($user->Tipo!=3){
                        echo "<script>window.history.back();</script>";
                        exit;
                    } ?>

                    <script>
                        window.onload = function() {
                            document.getElementById('propio').submit(); 
                        };
                    </script>
                    <?php
                    exit;
                }else{
                    $actualizar=$editar->UpdatePassword($_SESSION["user_id"],$newpassword);
                    if($actualizar!=null)
                    Core::addToastr('success', "Contraseña actualizada correctamente");
                    else{
                        $se=$_SESSION["user_id"];
                    Core::addToastr('warning', "Contraseña no actualizada");
        
                }   
            }
            }else{
                Core::addToastr('warning', "Contraseña Incorrecta");
                if($user->Tipo!=3){
                    echo "<script>window.history.back();</script>";
                    exit;
                }?>
                <script>
                    window.onload = function() {
                        document.getElementById('propio').submit(); 
                    };
                </script>
                <?php
                exit;
                
            }
        }
        if(!empty($nombre)){
        if($usuario->Nombre!=$nombre){
            $actualizar=$editar->UpdateNombre($_SESSION["user_id"],$nombre);
            if($actualizar!=null)
            Core::addToastr('success', "Nombre actualizado correctamente");
            else
            Core::addToastr('warning', "Nombre no actualizado");
        }

        if ($usuario->Apellido_p != $apellidop) {
            $actualizar=$editar->UpdateApellidoP($_SESSION["user_id"], $apellidop);
            if ($actualizar != null)
                Core::addToastr('success', "Apellido paterno actualizado correctamente");
            else
                Core::addToastr('warning', "Apellido paterno no actualizado");
        }

        if ($usuario->Apellido_m != $apellidom) {
            $actualizar=$editar->UpdateApellidoM($_SESSION["user_id"], $apellidom);
            if ($actualizar != null)
                Core::addToastr('success', "Apellido materno actualizado correctamente");
            else
                Core::addToastr('warning', "Apellido materno no actualizado");
        }

        if ($usuario->Nombre_Usuario != $user) {
            $verificarUser=$editar->VerificarUser($user);
            if($verificarUser->count==0){
            $editar->UpdateUser($_SESSION["user_id"], $user);
            if ($editar != null)
                Core::addToastr('success', "Usuario actualizado correctamente");
            else
                Core::addToastr('warning', "Usuario no actualizado");
            }else{
                Core::addToastr('warning', "Nombre de usuario ya existente");
            }
        }
    }
    if($user->Tipo!=3){
        Core::redir("./");
        exit;
    }    ?>

    <script>
        window.onload = function() {
            document.getElementById('propio').submit(); 
            
        };
    </script>
    
    <?php
 Core::redir("./?view=usuarios");
    }else  if(isset($_POST["opt"]) && $_POST["opt"] == "usuario" && isset($_POST['id'])){
        if($user->Tipo!=3){
            Core::addToastr('warning', "No tienes permiso para editar a este usuario");
            Core::redir("./");
            exit;
        } ?>

        <form id="usuario" action="./?view=editar_usuario&" method="post" >     
                <input type="hidden" name="opt" value="usuario">
                <input type="hidden" name="id" value="<?php echo $id=$_POST['id'];?>">
        </form>
        
        <?php 
        $nombre=$_POST['Nombre'];
        $apellidop=$_POST['ApellidoP'];
        $apellidom=$_POST['ApellidoM'];
        $user=$_POST['user'];
        $rango=$_POST['Rango'];
        $id=$_POST['id'];
        
        $usuario=$editar->getUsuario($id);
        if ($usuario->Tipo!=3){
        if($usuario->Nombre!=$nombre){
            $actualizar=$editar->UpdateNombre($id,$nombre);
            if($actualizar!=null)
            Core::addToastr('success', "Nombre actualizado correctamente");
            else
            Core::addToastr('warning', "Nombre no actualizado");
        }

        if ($usuario->Apellido_p != $apellidop) {
            $actualizar=$editar->UpdateApellidoP($id, $apellidop);
            if ($actualizar != null)
                Core::addToastr('success', "Apellido paterno actualizado correctamente");
            else
                Core::addToastr('warning', "Apellido paterno no actualizado");
        }

        if ($usuario->Apellido_m != $apellidom) {
            $actualizar=$editar->UpdateApellidoM($id, $apellidom);
            if ($actualizar != null)
                Core::addToastr('success', "Apellido materno actualizado correctamente");
            else
                Core::addToastr('warning', "Apellido materno no actualizado");
        }

        if ($usuario->Tipo != $rango) {
            $actualizar=$editar->UpdateRango($id, $rango);
            if ($actualizar != null)
                Core::addToastr('success', "Rango actualizado correctamente");
            else
                Core::addToastr('warning', "Rango no actualizado");
        }

        if ($usuario->Nombre_Usuario != $user) {
            $verificarUser=$editar->VerificarUser($user);
            if($verificarUser->count==0){
            $editar->UpdateUser($id, $user);
            if ($editar != null)
                Core::addToastr('success', "Usuario actualizado correctamente");
            else
                Core::addToastr('warning', "Usuario no actualizado");
            }else{
                Core::addToastr('warning', "Nombre de usuario ya existente");
            }
        }
        ?>
        <script>
            window.onload = function() {
                document.getElementById('usuario').submit(); 
            };
        </script>
        <?php
        Core::redir("./?view=usuarios");
        exit;
        }else{
            Core::addToastr('warning', "El usuario no se puede editar");
            ?>
        <script>
            window.onload = function() {
                document.getElementById('usuario').submit(); 
            };
            
        </script>
        <?php
        
        exit;
        }
    }else{
        Core::addToastr('warning', "Hubo un problema");
        Core::redir("./");
        exit;
    }

}else{
    echo "Inicia sesion";
}

?>