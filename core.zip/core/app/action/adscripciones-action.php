<?php
$universidades=new Universidades();
$Universidad=$_POST['Universidad'];


$verificar=$universidades->VerificarUniversidad($Universidad);
if($verificar==null){
Core::addToastr('warning',"Hubo un problema desconocido");
    echo "<script>window.history.back();</script>";
    exit;
}else if($verificar->count==0){
    $agregar=$universidades->setUniversidad($Universidad);
    if($agregar==null){
        Core::addToastr('warning',"Hubo un problema al agregar la universidad");
        echo "<script>window.history.back();</script>";
        exit;
    }else{
        Core::addToastr('success',"Agregado correctamente");
        Core::redir("?view=adscripciones");
        exit;
    }
}else if($verificar->count>0){
    Core::addToastr('warning',"La Universidad ya existe");
    echo "<script>window.history.back();</script>";
    exit;

} 