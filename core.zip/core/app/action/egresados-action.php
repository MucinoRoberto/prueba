<?php
$egresado = new Egresados();
$inscrito = new Inscritos();

// Almacenar los valores de $_POST en variables
$matricula = $_POST['matricula'];
$titulaciones = $_POST['Titulaciones'];
$egreso = $_POST['egreso'];
$periodo = $_POST['periodo'];
$trabajo = $_POST['trabajo'];
$movilidad = $_POST['Movilidad'];
$posgrado = $_POST['posgrado'];
$area = $_POST['area'];
$director = $_POST['Director'] ?? '';
$coodirector1 = $_POST['Coodirector1'] ?? '';
$correo1=$_POST['Correo1'];
$correo2=$_POST['Correo2'];

$verificar = $inscrito->verificacion($matricula);
$verificar2= $inscrito->verificacionAlta($matricula);

if($verificar2->contar==0){
if($verificar!=null){
if ($verificar == 0) {
    Core::addToastr('warning', "La matricula no existe");
} else {
    $verificar2 = $egresado->verificar($matricula);

    if ($verificar2->count == 0) {

        if ($titulaciones != 0 && $periodo != 0 && $movilidad != 0 && $area != 0) {
            if($titulaciones != 2){
                if ($director != 0) {
                    $success = $egresado->setEgresado($matricula, $titulaciones, $egreso, $periodo, $trabajo,$posgrado, $movilidad, $area);
                    $egresado->setDirector($matricula, $director);

                    if ($coodirector1 != 0) {
                        $egresado->setCoodirector($matricula, $coodirector1);
                    }
                } else {
                    Core::addToastr('warning', "Debe agregar director");
                    echo "<script>window.history.back();</script>";
                    exit;
                }
            }else{
                $success = $egresado->setEgresado($matricula, $titulaciones, $egreso, $periodo, $trabajo,$posgrado, $movilidad, $area);
                Core::addToastr('success', "Egresado agregado correctamente ^.^");
                Core::redir("./?view=agregar_egresados");
                exit;
            }

            if(!empty($_POST['telefono1'])){
                $egresado->setTelefono($matricula,$_POST['telefono1']);  
            }

            if(!empty($_POST['telefono2'])){
                $egresado->setTelefono($matricula,$_POST['telefono2']);
            }

            if(!empty($correo1)){
                $egresado->setCorreo($matricula,$correo1);
            }
            if(!empty($correo2)){
                $egresado->setCorreo($matricula,$correo2);
            }
        } else {
            Core::addToastr('warning', "Debe completar todos los campos.");
            echo "<script>window.history.back();</script>";
            exit;
        }

    } else {
        Core::addToastr('warning', "El egresado ya existe :(.");
        echo "<script>window.history.back();</script>";
        exit; 
    }

    if ($success) {
        Core::addToastr('success', "Egresado agregado correctamente ^.^");
        Core::redir("./?view=agregar_egresados");
        exit;
    } else {
        Core::addToastr('warning', "Hubo un error al agregar el egresado :(");
    }
}

echo "<script>window.history.back();</script>";
}else{
    Core::addToastr('warning', "Hubo un error al agregar el egresado :(");
}
}else{
    Core::addToastr('warning', "Alumno dado de baja");
        echo "<script>window.history.back();</script>";
        exit;
}
?>
