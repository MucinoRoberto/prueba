<?php

    if(isset($_POST["opt"]) && $_POST["opt"] == "eliminar"){
        $id=$_SESSION["user_id"];
        $usuario= Usuarios::getUsuario($id);
        if($usuario->Tipo==3){
        $alumno=new Inscritos;
        $id=$_POST['id'];

        $verificar=$alumno->deleteAlumno($id);

        if($verificar==null){
            Core::addToastr('warning', "Un error al dar de baja al alumno");
            echo "<script>window.history.back();</script>";
            exit;
        
        }else{
            Core::addToastr('success',"Alumno dado de baja correctamente");
            echo "<script>window.history.back();</script>";
            exit;
                
        }}else{
            Core::addToastr('warning', "No tienes permiso");
            Core::redir("./?view=index");
            exit;
        }
    }else if(isset($_POST["opt"]) && $_POST["opt"] == "alta"){
        $id=$_SESSION["user_id"];
        $usuario= Usuarios::getUsuario($id);
        if($usuario->Tipo==3){

        $alumno=new Inscritos;
        $id=$_POST['id'];

        $verificar=$alumno->checkAlumno($id);

        if($verificar==null){
            Core::addToastr('warning', "Un error al dar de alta al alumno");
            echo "<script>window.history.back();</script>";
            exit;
        
        }else{
            Core::addToastr('success',"Alumno dado de alta correctamente");
            echo "<script>window.history.back();</script>";
            exit;
                
        }
    }else{
        Core::addToastr('warning', "No tienes permiso");
        Core::redir("./?view=index");
        exit;
    }
    }
    
    
?>