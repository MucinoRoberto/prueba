<?php

$director= new Directores;
$id=$_POST['id'];
if(isset($_POST["opt"]) && $_POST["opt"] == "eliminar"){
    $verificar= $director->deleteDirector($id);

    if($verificar==null){
        Core::addToastr('warning', "Un error al dar de baja al direcror");
        echo "<script>window.history.back();</script>";
        exit;

    }else{
        Core::addToastr('success',"Director dado de baja correctamente");
        echo "<script>window.history.back();</script>";
        exit;
            
    }

} else  if(isset($_POST["opt"]) && $_POST["opt"] == "alta"){

    $verificar= $director->checkDirector($id);

    if($verificar==null){
        Core::addToastr('warning', "Un error al dar de alta al direcror");
        echo "<script>window.history.back();</script>";
        exit;

    }else{
        Core::addToastr('success',"Director dado de alta correctamente");
        echo "<script>window.history.back();</script>";
        exit;
            
    }

}
?>