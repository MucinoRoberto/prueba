<?php

    if(isset($_POST["opt"]) && $_POST["opt"] == "eliminar"){

        $movilidades=new Movilidades;
        $id=$_POST['id'];

        $verificar=$movilidades->deleteMovilidad($id);

        if($verificar==null){
            Core::addToastr('warning', " un error al eliminar la movilidad");
            echo "<script>window.history.back();</script>";
            exit;
        
        }else{
            Core::addToastr('success',"Movilidad eliminada correctamente");
            echo "<script>window.history.back();</script>";
            exit;
                
        }
    } else if(isset($_POST["opt"]) && $_POST["opt"] == "alta"){

        $movilidades=new Movilidades;
        $id=$_POST['id'];

        $verificar=$movilidades->checkMovilidad($id);

        if($verificar==null){
            Core::addToastr('warning', " un error al dar de alta la movilidad");
            echo "<script>window.history.back();</script>";
            exit;
        
        }else{
            Core::addToastr('success',"Movilidad dada de alta correctamente");
            echo "<script>window.history.back();</script>";
            exit;
                
        }
    }
    
?>