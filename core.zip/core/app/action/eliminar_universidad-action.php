<?php

$universidad= new Universidades;
$id=$_POST['id'];
if(isset($_POST["opt"]) && $_POST["opt"] == "eliminar"){
    $verificar= $universidad->deleteUniversidad($id);

    if($verificar==null){
        Core::addToastr('warning', "Un error al dar de baja a la Universidad");
        echo "<script>window.history.back();</script>";
        exit;

    }else{
        Core::addToastr('success',"Universidad dada de baja correctamente");
        echo "<script>window.history.back();</script>";
        exit;
            
    }
} else if(isset($_POST["opt"]) && $_POST["opt"] == "alta"){
    $verificar= $universidad->checkUniversidad($id);

    if($verificar==null){
        Core::addToastr('warning', "Un error al dar de alta a la Universidad");
        echo "<script>window.history.back();</script>";
        exit;

    }else{
        Core::addToastr('success',"Universidad dada de alta correctamente");
        echo "<script>window.history.back();</script>";
        exit;
            
    }
}

?>