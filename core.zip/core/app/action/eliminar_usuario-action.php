<?php

    if(isset($_POST["opt"]) && $_POST["opt"] == "eliminar"){

        $usuarios=new Usuarios;
        $id=$_POST['id'];
        
        $usuario=$usuarios->getUsuario($id);


        if($id==$_SESSION["user_id"] || $usuario->Tipo==3){
            Core::addToastr('warning', "Usuario invalido para eliminar");
            echo "<script>window.history.back();</script>";
            exit;
        }
    
        $verificar=$usuarios->deleteUsuario($id);

        if($verificar==null){
            Core::addToastr('warning', "Ocurrió un error al eliminar el usuario");
            echo "<script>window.history.back();</script>";
            exit;
        
        }else{
            Core::addToastr('success',"Usuario eliminado correctamente");
            echo "<script>window.history.back();</script>";
            exit;
                
        }
    }else if(isset($_POST["opt"]) && $_POST["opt"] == "alta"){
        
        $usuarios=new Usuarios;
        $id=$_POST['id'];
        
        $usuario=$usuarios->getUsuario($id);


        if($id==$_SESSION["user_id"] || $usuario->Tipo==3){
            Core::addToastr('warning', "Usuario invalido");
            echo "<script>window.history.back();</script>";
            exit;
        }
    
        $verificar=$usuarios->RegisterUsuario($id);

        if($verificar==null){
            Core::addToastr('warning', "Ocurrió un error al dar de alta al usuario");
            echo "<script>window.history.back();</script>";
            exit;
        
        }else{
            Core::addToastr('success',"Usuario dado de alta correctamente");
            echo "<script>window.history.back();</script>";
            exit;
                
        }


    }else{
        Core::addToastr('warning', "Ocurrio un problema");
        Core::redir("./");
        exit;
    }
    
?>