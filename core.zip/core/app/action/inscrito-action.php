<?php


$matricula = $_POST['Matricula'] ?? ''; 
$nombre = $_POST['Nombre'] ?? ''; 
$apellidoP = $_POST['ApellidoP'] ?? ''; 
$apellidoM = $_POST['ApellidoM'] ?? ''; 
$dob = $_POST['dob'] ?? ''; 
$genero = $_POST['Generos'] ?? ''; 
$fechaIngreso = $_POST['ingreso'] ?? ''; 
$facultad=$_POST['Facultad'];
$carrera=$_POST['Carrera'];

$inscrito = new Inscritos();

$verificar = $inscrito->verificacion($matricula);

if ($verificar == 0 ) {
    if($genero!=0 && $facultad!=0 && $carrera !=0){

        if (!empty($dob)) {
            $success = $inscrito->setInscritoDob($matricula, $nombre, $apellidoP, $apellidoM, $dob, $genero, $fechaIngreso);
        } else {
            $success = $inscrito->setInscrito($matricula, $nombre, $apellidoP, $apellidoM, $dob, $genero, $fechaIngreso);
        }

        if ($success) {
            Core::addToastr('success', "Alumno agregado correctamente");
        } else {
            Core::addToastr('warning', "Hubo un problema al agregar el alumno");
            echo "<script>window.history.back();</script>";
            exit;
        }

    }else{
        Core::addToastr('warning', "Debe completar todos los campos.");
        echo "<script>window.history.back();</script>";
        exit;
    }
} else {
    Core::addToastr('info', "¡Matrícula ya existe!");
    echo "<script>window.history.back();</script>";
    exit;
}


Core::redir("./?view=agregar_inscritos");
?>
