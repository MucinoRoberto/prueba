<?php
$Usuario=$_POST['Usuario'];
$Nombre=$_POST['Nombre'];
$ApellidoP=$_POST['ApellidoP'];
$ApellidoM=$_POST['ApellidoM'];
$tipo=$_POST['Rangos'];

$User= new Usuarios();

$verificar= $User->VerificarUser($Usuario);

if($verificar->count!=0){
    Core::addToastr('warning', "Nombre de usuario ya existente");
    echo "<script>window.history.back();</script>";
    exit;
}else{
    if($tipo==0 || $tipo==""){
        Core::addToastr('warning', "Ingresa un rango válido");
    echo "<script>window.history.back();</script>";
    exit;
    }
    $agregar=$User->setUsuario($Nombre,$ApellidoP,$ApellidoM,$Usuario,$tipo);
    if($agregar!=null){
        Core::addToastr('success', "Usuario agregado correctamente");
        Core::redir("./?view=agregar_usuarios");
        exit;
    }
}

?>