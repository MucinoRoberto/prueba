<?php

class Consultas extends Extra
{
	

    public static function getAreaDesarrollo(){
		try{
			$sql = "select * FROM seguimiento_egresados2.areas_desarrollo;";
			$query = Executor::doit($sql);
			return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir area de desarrollos" ;
			Core::redir("./?view=Error&Error_en_recibir_areas_de_desarrollo	");
			exit;
		}
    }

	public static function getTitulaciones(){
		try{
			$sql = "select * from seguimiento_egresados2.titulaciones;";
			$query = Executor::doit($sql);
			return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir titulaciones" ;
			Core::redir("./?view=Error&Error_en_recibir_titulaciones");
			exit;
		}
    }
    

	public static function getCarreras(){
		try{
			$sql = "SELECT * FROM seguimiento_egresados2.carreras;";
			$query = Executor::doit($sql);
			return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir carreras" ;
			Core::redir("./?view=Error&Error_en_recibir_carreras");
			exit;
		}
    }

	public static function getSituaciones(){
		try{
			$sql = "SELECT * FROM seguimiento_egresados2.status;";
			$query = Executor::doit($sql);
			return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir carreras" ;
			Core::redir("./?view=Error&Error_en_recibir_situaciones");
			exit;
		}
    }

	public static function getFacultades(){
		try{
			$sql = "SELECT * FROM seguimiento_egresados2.facultades;";
			$query = Executor::doit($sql);
			return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir facultades" ;
			Core::redir("./?view=Error&Error_en_recibir_facultades");
			exit;
		}
    }

	public static function getGeneros(){
		try{
			$sql = "select * from seguimiento_egresados2.generos;";
			$query = Executor::doit($sql);
			return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir generos" ;
			Core::redir("./?view=Error&Error_en_recibir_generos");
			exit;
		}
    } 


	


}
