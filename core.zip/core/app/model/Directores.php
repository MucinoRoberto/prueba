<?php
class Directores extends Extra
{
public function setDirectorExterno($nombre,$apellidop,$apellidom,$adscripcion,$correo,$num){
    try{
        $sql = "INSERT INTO `seguimiento_egresados2`.`directorest` (`Nombre`, `Apellido_p`, `Apellido_M`, `Adscripcion_fk`, `Interno`, `Correo`, `Num_personal`) VALUES ('$nombre', '$apellidop', '$apellidom', '$adscripcion', '0', '$correo', '$num');";
        return Executor::doit($sql);
    }catch(Exception){
        return null;
    }
    }

    public function setDirectorInterno($nombre,$apellidop,$apellidom,$correo,$num){
        try{
            $sql = "INSERT INTO `seguimiento_egresados2`.`directorest` (`Nombre`, `Apellido_p`, `Apellido_M`, `Interno`, `Correo`, `Num_personal`) VALUES ('$nombre', '$apellidop', '$apellidom', '1', '$correo', '$num');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public static function getDirectores(){
        try{
            $sql = "select * from seguimiento_egresados2.directorest where Status=1;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir directores" ;
			Core::redir("./?view=Error&Error_en_recibir_directores");
			exit;
        }
	}

    public static function getExterno($director){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.directores_externos where Id_director='$director' ;";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir externos" ;
			Core::redir("./?view=Error&Error_en_recibir_externos");
			exit;
        }
    }

    public static function getExternos(){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.directores_externos where Status=1 ;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir externos" ;
			Core::redir("./?view=Error&Error_en_recibir_externos");
			exit;
        }
    }

    public static function getExternosb(){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.directores_externos where Status=2 ;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir externos" ;
			Core::redir("./?view=Error&Error_en_recibir_externos");
			exit;
        }
    }
    
    public static function getInternos(){
        try{
            $sql = "SELECT * FROM directorest where Interno=1 and Status=1;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir internos" ;
			Core::redir("./?view=Error&Error_en_recibir_internos");
			exit;
        }
    }

    public static function getInternosb(){
        try{
            $sql = "SELECT * FROM directorest where Interno=1 and Status=2;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir internos" ;
			Core::redir("./?view=Error&Error_en_recibir_internos");
			exit;
        }
    }

    public static function getInterno($id){
        try{
            $sql = "SELECT * FROM directorest where Id_director='$id';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir interno" ;
			Core::redir("./?view=Error&Error_en_recibir_interno");
			exit;
        }
    }

    public function UpdateInternoAExterno($director,$adscripcion){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`directorest` SET `Adscripcion_fk` = '$adscripcion', `Interno` = '0' WHERE (`Id_director` = '$director');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function UpdateExternoAInterno($director){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`directorest` SET  `Interno` = '1' WHERE (`Id_director` = '$director');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function UpdateNombre($director,$nombre){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`directorest` SET `Nombre` = '$nombre' WHERE (`Id_director` = '$director');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function UpdateApellidoP($director,$apellidop){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`directorest` SET `Apellido_p` = '$apellidop' WHERE (`Id_director` = '$director');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function UpdateApellidoM($director,$apellidoM){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`directorest` SET `Apellido_M` = '$apellidoM' WHERE (`Id_director` = '$director');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }
    
    public function deleteDirector($id){
        try{
            $sql="UPDATE `seguimiento_egresados2`.`directorest` SET `Status` = '2' WHERE (`Id_director` = '$id');";
            return Executor::doit($sql);

        } catch(Exception $e){
            return null;
        }
    }

    public function checkDirector($id){
        try{
            $sql="UPDATE `seguimiento_egresados2`.`directorest` SET `Status` = '1' WHERE (`Id_director` = '$id');";
            return Executor::doit($sql);

        } catch(Exception $e){
            return null;
        }
    }


}