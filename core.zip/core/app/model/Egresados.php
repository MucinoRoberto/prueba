<?php
class Egresados extends Extra
{
    
    public function setEgresado($matricula, $metodo ,$egreso, $periodo, $trabajo,$posgrado, $movilidad, $area)
    {
        try{
            if ($periodo == 1) {
                $titulacion = date('Y-m-d', strtotime($egreso . "-01-31"));
            } else {
                $titulacion = date('Y-m-d', strtotime($egreso . "-07-31"));
            }
            $sql = "INSERT INTO egresados (Matricula, Metodo_titulacion_fk ,Posgrado ,Primer_trabajo, Movilidad_fk, Area_desarrollo_fk, Periodo,Fecha_Egreso) VALUES ('$matricula',$metodo,$posgrado,'$trabajo', $movilidad, $area, $periodo,'$titulacion')";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    
    public function setDirector($matricula,$director){
        try{
            $sql = "INSERT INTO alumno_director (Alumno_fk, Director_fk, Tipo_director) VALUES ('$matricula',$director,1)";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function setCoodirector($matricula,$director){
        try{
            $sql = "INSERT INTO alumno_director (Alumno_fk, Director_fk,Tipo_director) VALUES ('$matricula',$director,2)";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function setTelefono($matricula,$telefono){
        try{
            $sql = "INSERT INTO `seguimiento_egresados2`.`telefonos` (`Num_telefono`, `Egresado_fk`,`Status`) VALUES ('$telefono', '$matricula','1');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateEgresado($matricula,$egreso,$periodo,$trabajo,$movilidad,$area){
        try{
            if ($periodo == 1) {
                $titulacion = date('Y-m-d', strtotime($egreso . "-01-31"));
            } else {
                $titulacion = date('Y-m-d', strtotime($egreso . "-07-31"));
            }
        
            $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Fecha_Egreso` = '$titulacion', `Periodo` = '$periodo',  `Primer_trabajo` = '$trabajo', `Movilidad_fk` = '$movilidad', `Area_desarrollo_fk` = '$area' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateTelefono($telefono,$idtelefonoviejo){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`telefonos` SET `Num_telefono` = '$telefono' WHERE (`Id_telefono` = '$idtelefonoviejo'  );";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function DeleteTelefono($idtelefonoviejo){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`telefonos` SET `Status` = '2' WHERE (`Id_telefono` = '$idtelefonoviejo' );";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function DeleteCorreo($idcorreo){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`correos` SET `Status` = '2' WHERE (`Id_correos` = '$idcorreo' );";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    public function UpdateCorreo($correo,$idcorreo){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`correos` SET `Correo` = '$correo' WHERE(`Id_correos` = '$idcorreo');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    
    public function UpdateDirector($director,$matricula,$tipo){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumno_director` SET `Director_fk` = '$director' WHERE (`Alumno_fk` = '$matricula' and `Tipo_director` = '$tipo');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function setCorreo($matricula,$correo){
        try{
            $sql = "INSERT INTO `seguimiento_egresados2`.`correos` (`Correo`, `Egresado_fk`, `Status`) VALUES ('$correo', '$matricula', '1');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    
    public static function getDatos(){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.datos_egresados order by Matricula;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir egresados" ;
            Core::redir("./?view=Error&Error_en_recibir_egresados");
            exit;
        }
    }

    public static function getEgresado($matricula){
        try{
        $sql = "SELECT * FROM seguimiento_egresados2.datos_egresados where matricula='$matricula';";
		$query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
        }catch(Exception $e){
			echo "Error en recibir egresado" ;
			Core::redir("./?view=Error&Error_en_recibir_egresado");
			exit;
		}
    }

    public static function getDirector($matricula){
        try{
        $sql = "SELECT Director_fk FROM seguimiento_egresados2.alumno_director where Tipo_director=1 and Alumno_fk= '$matricula';";
		$query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
        }catch(Exception $e){
			return null;
		}
    }

    public static function getCodirector($matricula){
        try{
        $sql = "SELECT Director_fk FROM seguimiento_egresados2.alumno_director where Tipo_director=2 and Alumno_fk= '$matricula';";
		$query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
        }catch(Exception $e){
			return null;
		}
    }

    public static function verificar($matricula){
        try{
            $sql = "SELECT count(Matricula) as count FROM seguimiento_egresados2.egresados where Matricula='$matricula';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch (Exception $e){
            return null;
        }

    }
   
    public static function getTotalTelefonos($matricula){
        try{
            $sql = "SELECT count(*) as total  FROM seguimiento_egresados2.telefonos where Egresado_fk='$matricula' and Status=1;";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir telefonos" ;
            Core::redir("./?view=Error&Error_en_recibir_total_telefonos");
            exit;
        }
        
    }

    public static function getTotalCorreos($matricula){
        try{
            $sql = "SELECT count(*) as total  FROM seguimiento_egresados2.correos where Egresado_fk='$matricula' and Status=1;";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir correos" ;
            Core::redir("./?view=Error&Error_en_recibir_correos");
            exit;
        }
    }

    public static function getDirectores($matricula){
        try{
            $sql = "SELECT t.Tipo,ad.Id_aludir,d.Id_director,d.Interno , d.Nombre, d.Apellido_p, d.Apellido_M FROM tipo_directores t,alumno_director ad, directorest d where ad.Director_fk= d.Id_director and t.Id_tipo=ad.Tipo_director and Alumno_fk='$matricula';";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir directores" ;
            Core::redir("./?view=Error&Error_en_recibir_directores");
            exit;
        }
    }

    public static function getCountDirectores($matricula){
        try{
            $sql = "SELECT count(*) as count FROM tipo_directores t,alumno_director ad, directorest d where ad.Director_fk= d.Id_director and t.Id_tipo=ad.Tipo_director and Alumno_fk='$matricula';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch (Exception $e){
            return null;
        }
    }

    public static function getTelefonos($matricula){
        try{
            $sql = "SELECT * FROM telefonos where Egresado_fk='$matricula' and Status=1;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir telefonos" ;
            Core::redir("./?view=Error&Error_en_recibir_telefonos");
            exit;
        }
    }

    public static function getCorreo($matricula){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.correos where Egresado_fk='$matricula' and Status=1;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir correos" ;
            Core::redir("./?view=Error&Error_en_recibir_correos");
            exit;
        }
    }
    public function UpdatePeriodo($matricula,$periodo){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Periodo` = '$periodo' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    
    public function UpdateArea($matricula,$area){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Area_desarrollo_fk` = '$area' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    public function UpdateMovilidad($matricula,$movilidad){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET  `Movilidad_fk` = '$movilidad' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    public function UpdateTrabajo($matricula,$trabajo){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET  `Primer_trabajo` = '$trabajo' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateEgreso($matricula,$egreso,$periodo){
    try{
        if ($periodo == 1) {
            $titulacion = date('Y-m-d', strtotime($egreso . "-01-31"));
        } else {
            $titulacion = date('Y-m-d', strtotime($egreso . "-07-31"));
        }

        $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Fecha_Egreso` = '$titulacion' WHERE (`Matricula` = '$matricula');";
        return Executor::doit($sql);
    }catch (Exception $e){
        return null;
    }
}
}
