<?php
class Inscritos extends Extra
{

    
    public function setInscrito($matricula, $nombre, $apellidop, $apellidom, $dob, $genero, $anio){
        try{
            $ingreso = date('Y-m-d', strtotime($anio . "-08-01"));
            $sql = "INSERT INTO alumnos_inscritos (Matricula, Nombre, Apellido_p, Apellido_M, Genero_fk, Carrera_fk, Nivel_fk, Facultad_fk, Fecha_Ingreso, Status  ) VALUES ('$matricula', '$nombre', '$apellidop', '$apellidom', $genero, '1', '1', '1', '$ingreso', '1');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public static function getMatriculas(){
		try{
			$sql = "select * from seguimiento_egresados2.alumnos_inscritos where Status=1;";
			$query = Executor::doit($sql);
			return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir alumnos inscritos" ;
			Core::redir("./?view=Error&Error_en_recibir_alumnos_inscritos");
			exit;
		}
    } 

    public static function verificacionAlta($matricula){
		try{
			$sql = "select count(*) as contar from seguimiento_egresados2.alumnos_inscritos where Status=5 and  Matricula='$matricula';";
			$query = Executor::doit($sql);
			return Model::one($query[0], new Consultas());
		}catch(Exception $e){
			return null;
		}
    } 

    public function setInscritoDob($matricula, $nombre, $apellidop, $apellidom, $dob, $genero, $anio){
        try{
            $ingreso = date('Y-m-d', strtotime($anio . "-08-01"));
            $sql = "INSERT INTO alumnos_inscritos (Matricula, Nombre, Apellido_p, Apellido_M,Dob ,Genero_fk, Carrera_fk, Nivel_fk, Facultad_fk, Fecha_Ingreso, Status  ) VALUES ('$matricula', '$nombre', '$apellidop', '$apellidom','$dob', $genero, '1', '1', '1', '$ingreso', '1');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function verificacion($matricula){
        try{
            $sql = "SELECT count(Matricula) as numero FROM seguimiento_egresados2.alumnos_inscritos where Matricula='$matricula';";
            $result = Executor::doit($sql);
        
            if ($result[0] !== false && $result[0]->num_rows > 0) {

                $row = $result[0]->fetch_assoc();
                return $row['numero'];

            } else {
                return 0;
            }
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateAlumno($matricula,$carrera,$ingreso){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Carrera_fk` = '$carrera', `Fecha_Ingreso` = '$ingreso-08-01'WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    
    public function deleteAlumno($matricula){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Status` = '5' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    
    public function checkAlumno($matricula){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Status` = '1' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public static function getDatos(){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.inscritos2  where Status_id=1 order by Matricula;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir datos de alumno";
            Core::redir("./?view=Error&Error_en_recibir_datos_de_alumno");
            exit;
        }
    }

    public static function getDatosS(){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.inscritos2  where Status_id=5 order by Matricula";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir datos de alumno";
            Core::redir("./?view=Error&Error_en_recibir_datos_de_alumno");
            exit;
        }
    }
    
    public static function getAlumno($matricula){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.alumnos_inscritos where `Matricula` = '$matricula';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir inscrito" ;
            Core::redir("./?view=Error&Error_en_recibir_inscrito");
            exit;
        }
    }

    public static function getAlumno2($matricula){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.inscritos2 where `Matricula` = '$matricula';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir inscrito" ;
            Core::redir("./?view=Error&Error_en_recibir_inscrito");
            exit;
        }
    }

    public function UpdateDob($matricula,$dob){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Dob` = '$dob' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateIngreso($ingreso,$matricula){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Fecha_Ingreso` = '$ingreso-08-01' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateCarrera($matricula,$carrera){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Carrera_fk` = '$carrera' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    public function UpdateApellidoM($apellidoM,$matricula){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Apellido_m` = '$apellidoM' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    public function UpdateApellidoP($apellidoP,$matricula){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Apellido_p` = '$apellidoP' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
    public function UpdateNombre($nombre,$matricula){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Nombre` = '$nombre' WHERE (`Matricula` = '$matricula');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }
}
