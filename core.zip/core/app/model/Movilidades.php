<?php

class Movilidades extends Extra{
    public static function VerificarDependencia($dependencia){
        try{
        $sql = "SELECT count(*) as count FROM seguimiento_egresados2.movilidades where Dependencia='$dependencia';";
		$query = Executor::doit($sql);
		return Model::one($query[0], new Consultas());
        }catch(Exception){
            return null;
        }

    }

    public static function getMovilidades(){
		try{
        $sql = "select * FROM seguimiento_egresados2.movilidades where Status=1;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir movilidades" ;
			Core::redir("./?view=Error&Error_en_recibir_movilidades");
			exit;
		}
    }
    
    public static function getMovilidadesS(){
		try{
        $sql = "select * FROM seguimiento_egresados2.movilidades order by Status ;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
		}catch(Exception $e){
			echo "Error en recibir movilidades" ;
			Core::redir("./?view=Error&Error_en_recibir_movilidades");
			exit;
		}
    }

    public function setMovilidad($dependencia,$pais){
        try{
        $sql = "INSERT INTO `seguimiento_egresados2`.`movilidades` (`Dependencia`, `Pais`) VALUES ('$dependencia',  '$pais');";
        return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function deleteMovilidad($id){
        try{
        $sql = "UPDATE `seguimiento_egresados2`.`movilidades` SET `Status` = '2' WHERE (`Id_movilidad` = '$id');";
        return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function checkMovilidad($id){
        try{
        $sql = "UPDATE `seguimiento_egresados2`.`movilidades` SET `Status` = '1' WHERE (`Id_movilidad` = '$id');";
        return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }
}