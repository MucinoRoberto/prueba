<?php

class Universidades extends Extra{

    public static function getUniversidades(){
		try{
            $sql = "SELECT * FROM seguimiento_egresados2.universidades where Status=1;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir universidades" ;
            Core::redir("./?view=Error&Error_en_recibir_universidades");
            exit;
        }
    }

    public static function getUniversidadesS(){
		try{
            $sql = "SELECT * FROM seguimiento_egresados2.universidades order by Status;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch(Exception $e){
            echo "Error en recibir universidades" ;
            Core::redir("./?view=Error&Error_en_recibir_universidades");
            exit;
        }
    }

    public static function VerificarUniversidad($universidad){
        try{
        $sql = "SELECT count(*) as count FROM seguimiento_egresados2.universidades where Nombre_Universidad='$universidad' and Status=1;";
		$query = Executor::doit($sql);
		return Model::one($query[0], new Consultas());
        }catch(Exception){
            return null;
        }

    }

    public function setUniversidad($universidad){
        try{
        $sql = "INSERT INTO `seguimiento_egresados2`.`universidades` (`Nombre_Universidad`) VALUES ('$universidad');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function deleteUniversidad($universidad){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`universidades` SET `Status` = '2' WHERE (`Id_Universidad` = '$universidad');";
                return Executor::doit($sql);
            }catch(Exception){
                return null;
            }
    }

    public function checkUniversidad($universidad){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`universidades` SET `Status` = '1' WHERE (`Id_Universidad` = '$universidad');";
                return Executor::doit($sql);
            }catch(Exception){
                return null;
            }
    }
}