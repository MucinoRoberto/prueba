<?php

class Usuarios extends Extra{ 

    public static function setUsuario($nombre,$apellidop,$apellidom,$usuario,$tipo){
        try{
            $sql = "INSERT INTO `seguimiento_egresados2`.`usuarios` (`Nombre`, `Apellido_p`, `Apellido_m`, `Nombre_Usuario`, `Password`, `Tipo_fk`, `Status`, `Facultad`, `Carrera`) VALUES ('$nombre', '$apellidop', '$apellidom', '$usuario', '123456', '$tipo', '1', '1', '1');";
                return Executor::doit($sql);
            }catch(Exception){
                return null;
            }
    }

    public static function getUsuario($id){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.users where ID_usuario='$id';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir usuario" ;
			Core::redir("./?view=Error&Error_en_recibir_usuario");
			exit;
        }
    }

    public static function getUsuarios(){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.users order by Status;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir usuarios";
			Core::redir("./?view=Error&Error_en_recibir_usuarios");
			exit;
        }
    }

    public function deleteUsuario($id){
        try{
        $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Status` = '2' WHERE (`ID_usuario` = '$id');";
        return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public function RegisterUsuario($id){
        try{
        $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Status` = '1' WHERE (`ID_usuario` = '$id');";
        return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

    public static function getTipos(){
        try{
            $sql = "SELECT * FROM seguimiento_egresados2.tipo_usuarios;";
            $query = Executor::doit($sql);
            return Model::many($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir usuarios";
			Core::redir("./?view=Error&Error_en_recibir_tipos_usuarios");
			exit;
        }
    }

    public function VerificarUser($user){
        try{
            $sql = "SELECT count(*) as count FROM seguimiento_egresados2.users where Nombre_Usuario='$user';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir usuarios";
			Core::redir("./?view=Error&Error_en_recibir_usuarios_existentes");
			exit;
        }
    }

    public function VerificarUsuario($user,$password){
        try{
            $sql = "select count(*) as count from seguimiento_egresados2.usuarios where Nombre_Usuario='$user'  and Password='$password';";
            $query = Executor::doit($sql);
            return Model::one($query[0], new Consultas());
        }catch (Exception $e){
            echo "Error en recibir usuario";
			Core::redir("./?view=Error&Error_en_recibir_usuarios_existentes");
			exit;
        }
    }

    public function UpdateNombre($id,$nombre){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Nombre` = '$nombre' WHERE (`ID_usuario` = '$id');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateRango($id,$rango){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Tipo_fk` = '$rango' WHERE (`ID_usuario` = '$id');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateApellidoP($id,$apellidop){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Apellido_p` = '$apellidop' WHERE (`ID_usuario` = '$id');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateApellidoM($id,$apellidom){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Apellido_m` = '$apellidom' WHERE (`ID_usuario` = '$id');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdatePassword($id,$password){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Password` = '$password', `sesion` = '1' WHERE (`ID_usuario` = '$id');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

    public function UpdateUser($id,$user){
        try{
            $sql = "UPDATE `seguimiento_egresados2`.`usuarios` SET `Nombre_Usuario` = '$user' WHERE (`ID_usuario` = '$id');";
            return Executor::doit($sql);
        }catch (Exception $e){
            return null;
        }
    }

}