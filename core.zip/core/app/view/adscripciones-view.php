<?php if(isset($_SESSION["user_id"])){
  
  $id=$_SESSION["user_id"];
  $usuario= Usuarios::getUsuario($id);
 if($usuario->Tipo==3){?>
 <div class="col-md">
   <input type="text" id="search" placeholder="Buscar..." class="form-control mb-3" onkeyup="filterTable()">
 </div>
 <table class="table">
   <thead>
     <tr>
       <th scope="col">Universidad</th>
       <th>Eliminar</th>
     </tr>
   </thead>
   <?php $Movilidades=Universidades::getUniversidadesS();?>
   <tbody id="universidadTableBody">
     <?php if($Movilidades!=null){
       $count=0;
       foreach($Movilidades as $movilidad){?>
     <tr>
       <th scope="row" class="table-light"><?php echo $movilidad->Nombre_Universidad?></th>
       <td class="table-secondary">
         <?php if($movilidad->Status==1) {?>
         <form id="eliminar<?php echo $count?>" action="./?action=eliminar_universidad&" method="post">
           <input type="hidden" name="opt" value="eliminar">
           <input type="hidden" name="id" value="<?php echo $movilidad->Id_Universidad ?>">
           <button class="btn btn-danger" type="submit" data-bs-toggle="tooltip" title="Dar de baja <?php echo $movilidad->Nombre_Universidad ?>">
             <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-octagon" viewBox="0 0 16 16">
               <path d="M4.54.146A.5.5 0 0 1 4.893 0h6.214a.5.5 0 0 1 .353.146l4.394 4.394a.5.5 0 0 1 .146.353v6.214a.5.5 0 0 1-.146.353l-4.394 4.394a.5.5 0 0 1-.353.146H4.893a.5.5 0 0 1-.353-.146L.146 11.46A.5.5 0 0 1 0 11.107V4.893a.5.5 0 0 1 .146-.353zM5.1 1 1 5.1v5.8L5.1 15h5.8l4.1-4.1V5.1L10.9 1z"/>
               <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
             </svg>
           </button>
         </form>
         <script>
           document.getElementById('eliminar<?php echo $count?>').addEventListener('submit', function(event) {
               let confirmation = confirm('¿Está seguro que quiere dar de baja a <?php echo $movilidad->Nombre_Universidad?>?');
               if (!confirmation) {
                   event.preventDefault(); 
               }
           });
         </script>
         <?php }else{ ?>
           <form id="alta1<?php echo $count?>" action="./?action=eliminar_universidad&" method="post">
           <input type="hidden" name="opt" value="alta">
           <input type="hidden" name="id" value="<?php echo $movilidad->Id_Universidad ?>">
           <button class="btn btn-success" type="submit" data-bs-toggle="tooltip" title="Dar de alta <?php echo $movilidad->Nombre_Universidad ?>">
           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-lg" viewBox="0 0 16 16">
               <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"/>
           </svg>
           </button>
         </form>
         <script>
             document.getElementById('alta1<?php echo $count?>').addEventListener('submit', function(event) {
               let confirmation = confirm('¿Está seguro que quiere dar de alta a <?php echo $movilidad->Nombre_Universidad?>?');
               if (!confirmation) {
                   event.preventDefault(); 
               }
             });
         </script>
         <?php } ?>
       </td>
     </tr>
     <?php $count=$count+1;}
     }else{
       echo "Hubo un problema";
       Core::redir("./?view=Error");
       exit;
     }?>
   </tbody>
 </table>
 <script>
   function filterTable() {
     var input, filter, table, tbody, rows, cell, i, txtValue;
     input = document.getElementById("search");
     filter = input.value.toLowerCase();
     table = document.querySelector("table");
     tbody = table.querySelector("tbody");
     rows = tbody.getElementsByTagName("tr");
     
     for (i = 0; i < rows.length; i++) {
       cell = rows[i].getElementsByTagName("th")[0];
       if (cell) {
         txtValue = cell.textContent || cell.innerText;
         if (txtValue.toLowerCase().indexOf(filter) > -1) {
           rows[i].style.display = "";
         } else {
           rows[i].style.display = "none";
         }
       }       
     }
   }
 </script>
<?php }else{ 
 Core::addToastr('warning', "No tienes permiso");
 Core::redir("./?view=index");
 exit; } }else{?>
Inicia sesion
<?php }?>
