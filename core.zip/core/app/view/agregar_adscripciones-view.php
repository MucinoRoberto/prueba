<?php if(isset($_SESSION["user_id"])){
     $id=$_SESSION["user_id"];
     $usuario= Usuarios::getUsuario($id);
    if($usuario->Tipo==3){?>
<div class="row justify-content-center">

    <div class="col-md-7">
    <h2>Agrega los datos de la Universidad</h2>
    <br>
    <?php
     $Universidades= Universidades::getUniversidades();?>
        <form action="./?action=adscripciones" method="post">
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input  class="form-select" list="Universidades" name="Universidad" id="Universidad" placeholder="Ingrese una Universidad diferente a las opciones" required>
                            <datalist id="Universidades" >             
                                <?php if($Universidades!=null){
                                        foreach ($Universidades as $movilidad) { ?>
                                <option value="<?php echo $movilidad->Nombre_Universidad; ?>"></option>
                                <?php } 
                                    }else {
                                        echo "Hubo un problema";
                                        Core::redir("./?view=Error");
                                        exit;
                                    } ?>
                            </datalist>
                        <label for="Universidad" class="form-label">Universidad</label>
                    </div>
                <br>
                <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
            </div>
            
        </form>
    </div>
</div>
<?php }else{ Core::addToastr('warning', "No tienes permiso");
    Core::redir("./?view=index");
    exit; }}else{?>
  incia sesion
  <?php }?>