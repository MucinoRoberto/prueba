<?php if(isset($_SESSION["user_id"])){?>
<div class="row justify-content-center">
    <div class="col-md-7">
        <div class="form-section">

            <h2>LLena los datos del alumno nuevo</h2>
            <br>
            <form action="./?action=inscrito&" method="post">
            <div class="row">
                <div class="col">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="Matricula" id="Matricula" minlength="9" maxlength="9"  placeholder="S00000000"required>
                        <label for="Matricula">Matricula</label>
                    </div>
                </div>
                
            </div>
            <br>
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control"name="Nombre" id="Nombre" placeholder="S00000000" required>
                        <label for="Nombre">Nombre</label>
                    </div>
                    <br>
                </div>
                
            
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="ApellidoP" id="ApellidoP" placeholder="S00000000" required>
                        <label for="ApellidoP">Apellido Paterno</label>
                    </div>
                    <br>
                </div>
            </div>
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="ApellidoM" id="ApellidoM" placeholder="S00000000" required>
                        <label for="ApellidoM">Apellido Materno</label>
                    </div>
                    <br>
                </div>
                <?php 
                    $Generos = Consultas::getGeneros(); 
                ?>
                <div class="col-md-6">
                    <div class="form-floating">
                        <select  class="form-select"  id="Genero" name="Generos" required placeholder="Ingresa el genero..." required>
                            <option value="0" selected>...</option>
                            <?php foreach ($Generos as $genero) { ?>
                            <option value="<?php echo $genero->Id_generos; ?>"><?php echo $genero->Genero; ?></option>
                            <?php } ?>
                        </select>
                        <label for="Generos">Genero</label>
                    </div>
                </div>
                
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="number" class="form-control" name="ingreso" id="ingreso" placeholder="S00000000"required>
                        <label for="ingreso">Año de ingreso</label>
                    </div>
                    <br>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="date" class="form-control" name="dob" id="dob" placeholder="S00000000" >
                        <label for="dob">Fecha de nacimiento</label>
                    </div>
                    <br>
                </div>
                
            </div>

            <div class="row">
                <?php 
                $Facultades= Consultas::getFacultades();?>
                <div class="col-md-6">
                    <div class="form-floating">
                        <select  class="form-select"  id="facultad" name="Facultad" required placeholder="" required >
                        <option value="0" selected>...</option>
                            <?php foreach ($Facultades as $facultad) { ?>
                            <option value="<?php echo $facultad->Id_facultad; ?>"><?php echo $facultad->Nombre_facultad; ?></option>
                            <?php } ?>
                        </select>
                        <label for="Facultad">Facultad</label>
                    
                    </div>
                </div>
                <?php 
                    $Carreras = Consultas::getCarreras(); 
                ?>
                <div class="col-md-6">
                    <div class="form-floating">
                        <select  class="form-select"  id="Carrera" name="Carrera" required placeholder="" required >
                        <option value="0" selected>...</option>
                            <?php foreach ($Carreras as $carrera) { ?>
                            <option value="<?php echo $carrera->Id_carrera; ?>"><?php echo $carrera->Nombre_carrera; ?></option>
                            <?php } ?>
                        </select>
                        <label for="Carrera">Carrera</label>
                    </div>
                </div>
            </div>
            <br>
            <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
        
            </form>
            <br>
            
        </div>
    </div>
</div>
<?php }else{?>
  incia sesion
  <?php }?>