<?php if(isset($_SESSION["user_id"])){
     $id=$_SESSION["user_id"];
     $usuario= Usuarios::getUsuario($id);
    if($usuario->Tipo==3){?>
<div class="row justify-content-center">
    <div class="col-md-7">
        <div class="form-section">

            <h2>Ingresa la movilidad</h2>
            <br>
            <form action="./?action=movilidades&" method="post">
                <div class="row">
                    <?php 
                    $Movilidades = Movilidades::getMovilidades(); 
                    ?>
                    <div class="col-md">
                        <div class="form-floating">
                            <input  class="form-select" list="dependencias" name="dependencia" id="dependencia" placeholder="Ingrese una dependencia diferente a las opciones" required>
                                <datalist id="dependencias" >
                                    
                                    <?php foreach ($Movilidades as $movilidad) { ?>
                                    <option value="<?php echo $movilidad->Dependencia; ?>"></option>
                                    <?php } ?>
                                </datalist>
                            <label for="dependencia" class="form-label">Dependencia</label>
                        </div>
                        <br>
                    </div>
                </div>
                <!-- <div class="row">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" class="form-control"name="Pais" id="Pais" placeholder="S00000000" >
                            <label for="Pais">País</label>
                        </div>
                        <br>
                    </div>
                </div> -->
                <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
            </form>
            <br>
            
        </div>
    </div>
</div>
<?php }else{ Core::addToastr('warning', "No tienes permiso");
    Core::redir("./?view=index");
    exit;} }else{?>
  incia sesion
  <?php }?>