<?php if(isset($_SESSION["user_id"])){
  
  $id=$_SESSION["user_id"];
  $usuario= Usuarios::getUsuario($id);
 if($usuario->Tipo==3){?>
 <div class="row justify-content-center">
    <div class="col-md-7">
        <div class="form-section">
 <h2>LLena los datos del usuario nuevo</h2>
            <br>
            <form action="./?action=usuario&" method="post">
            <div class="row">
                <div class="col">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="Usuario" id="Usuario" placeholder="S00000000" required>
                        <label for="Usuario">Nombre de Usuario</label>
                    </div>
                </div>
                
            </div>
            <br>
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control"name="Nombre" id="Nombre" placeholder="S00000000" required>
                        <label for="Nombre">Nombre</label>
                    </div>
                    <br>
                </div>
    
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="ApellidoP" id="ApellidoP" placeholder="S00000000" required>
                        <label for="ApellidoP">Apellido Paterno</label>
                    </div>
                    <br>
                </div>

            </div>
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="ApellidoM" id="ApellidoM" placeholder="S00000000" required>
                        <label for="ApellidoM">Apellido Materno</label>
                    </div>
                    <br>
                </div>
                <?php 
                    $Rangos = Usuarios::getTipos(); 
                ?>
                <div class="col-md-6">
                    <div class="form-floating">
                        <select  class="form-select"  id="Rango" name="Rangos" required placeholder="Ingresa el rango..." required>
                            <option value="0" selected>...</option>
                            <?php foreach ($Rangos as $rango) { ?>
                            <option value="<?php echo $rango->Id_tipo; ?>"><?php echo $rango->Tipo; ?></option>
                            <?php } ?>
                        </select>
                        <label for="Rangos">Rango</label>
                    </div>
                </div>
                
            </div>
            
            
            <br>
            <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
        
            </form>
            <br>
            
        </div>
    </div>
</div>
<?php }else{ 
 Core::addToastr('warning', "No tienes permiso");
   Core::redir("./?view=index");
   exit; } }else{?>
 Inicia sesion
 <?php }?>
 <script>
   
    // Selecciona el formulario y el campo de rango
    const form = document.querySelector('form');
    const rangoSelect = document.getElementById('Rango');

    form.addEventListener('submit', function(event) {
        if (rangoSelect.value == "0") {
            alert("Debes seleccionar un rango válido.");
            event.preventDefault(); // Evita el envío del formulario
        }
    });
</script>
      