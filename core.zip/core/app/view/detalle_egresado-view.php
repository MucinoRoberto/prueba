<?php 
if(isset($_POST["opt"]) && $_POST["opt"] == "edit"){

    
        $egresado=Egresados::getEgresado($_POST['matricula']);
       
     
}



?>

hola <?php echo $egresado->Nombre;
