<?php if(isset($_SESSION["user_id"])){
   $id=$_SESSION["user_id"];
   $usuario= Usuarios::getUsuario($id);
  if($usuario->Tipo==3){?>
<table class="table">
<?php   
    $Universidades= Universidades::getUniversidades();
        ?>
        <div class="row">
         <div class="col-md">
    <input type="text" id="search" placeholder="Buscar..." class="form-control mb-3" onkeyup="filterTable()">
    </div>  
        <div class="col-md">
            <select id="filterAdscricpion" class="form-select" onchange="filterTable()">
                <option value="">Todas las adscripciones</option>
                <?php foreach ($Universidades as $universidad) { ?>
                    <option value="Universidad Veracruzana">Universidad Veracruzana</option> 
                    <option value="<?php echo $universidad->Nombre_Universidad;  ?>">
                        <?php echo $universidad->Nombre_Universidad;  ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        </div>
  <thead>
    <tr class="table-light">
      <th scope="col">Nombre</th>
      <th scope="col">Apellido Paterno</th>
      <th scope="col">Apellido Materno</th>
      <th scope="col">Adscripcion</th>
      <th scope="col">Editar</th>
      <!-- <th scope="col">Correo</th>
      <th scope="col">Numero de personal</th> -->
    </tr>
  </thead>
  <tbody>
  <?php 

  $Internos = Directores::getInternos(); 
?>
<?php $count=0;
foreach ($Internos as $interno) { ?>
    <tr>
      <th scope="row"  class="table-light" ><?php echo $interno->Nombre ?></th>
      <td class="table-secondary"><?php echo $interno->Apellido_p?></td>
      <td  class="table-light" ><?php echo $interno->Apellido_M ?></td>
      <td class="table-secondary">Universidad Veracruzana</td>
      <td class="table-light" >
        <div class="col" style="display: flex;">
            <form action="./?view=editar_director&" method="post" style="margin-right: 10px;">
                <input type="hidden" name="opt" value="interno">
                <input type="hidden" name="id" value="<?php echo $interno->Id_director; ?>">
                <button class="btn btn-primary" type="submit" data-bs-toggle="tooltip" title="Editar datos de <?php echo $interno->Nombre ?>">
                    <svg xmlns="http://www.w3.org/2000/svg"  href="?view=agregar_inscritos" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                    </svg>
                </button>
            </form>
            
            <form id="eliminar<?php echo $count?>" action="./?action=eliminar_director&" method="post">
              <input type="hidden" name="opt" value="eliminar">
              <input type="hidden" name="id" value="<?php echo $interno->Id_director; ?>">
              <button class="btn btn-danger" type="submit" data-bs-toggle="tooltip" title="Dar de baja <?php echo $interno->Nombre ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-octagon" viewBox="0 0 16 16">
                  <path d="M4.54.146A.5.5 0 0 1 4.893 0h6.214a.5.5 0 0 1 .353.146l4.394 4.394a.5.5 0 0 1 .146.353v6.214a.5.5 0 0 1-.146.353l-4.394 4.394a.5.5 0 0 1-.353.146H4.893a.5.5 0 0 1-.353-.146L.146 11.46A.5.5 0 0 1 0 11.107V4.893a.5.5 0 0 1 .146-.353zM5.1 1 1 5.1v5.8L5.1 15h5.8l4.1-4.1V5.1L10.9 1z"/>
                  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
                </svg>
              </button>
            </form>
            <script>
              document.getElementById('eliminar<?php echo $count?>').addEventListener('submit', function(event) {
                let confirmation = confirm('¿Está seguro que quiere dar de baja a <?php echo $interno->Nombre ?>?');
                if (!confirmation) {
                    event.preventDefault(); 
                }
            });
            </script>
            </div>
        </td>
      <!-- <td class="table-light" ><?php echo $interno->Correo ?></td>
      <td class="table-secondary"><?php echo $interno->Num_personal ?></td> -->
    </tr>
<?php  $count=$count+1;
    } 

    $Externos = Directores::getExternos(); 
    foreach ($Externos as $externo) { ?>
    <tr>
      <th scope="row" class="table-light" ><?php echo $externo->Nombre ?></th>
      <td class="table-secondary"><?php echo $externo->Apellido_p?></td>
      <td class="table-light" ><?php echo $externo->Apellido_M ?></td>
      <td class="table-secondary"><?php echo $externo->Nombre_Universidad ?></td>
      <!-- <td class="table-light" ><?php echo $externo->Correo ?></td>
      <td class="table-secondary"><?php echo $externo->Num_personal ?></td>
  -->
    <td class="table-light" >
      <div class="col-md" style="display: flex;">
        <form action="./?view=editar_director&" method="post" style="margin-right: 10px;">
            <input type="hidden" name="opt" value="externo">
            <input type="hidden" name="id" value="<?php echo $externo->Id_director; ?>">
            <button class="btn btn-primary" type="submit" data-bs-toggle="tooltip" title="Editar datos de <?php echo $externo->Nombre ?>">
                <svg xmlns="http://www.w3.org/2000/svg"  href="?view=agregar_inscritos" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                </svg>
            </button>
        </form>
        <form id="eliminar<?php echo $count?>" action="./?action=eliminar_director&" method="post">
              <input type="hidden" name="opt" value="eliminar">
              <input type="hidden" name="id" value=" <?php echo $externo->Id_director; ?>">
              <button class="btn btn-danger" type="submit" data-bs-toggle="tooltip" title="Dar de baja <?php echo $externo->Nombre ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-octagon" viewBox="0 0 16 16">
                  <path d="M4.54.146A.5.5 0 0 1 4.893 0h6.214a.5.5 0 0 1 .353.146l4.394 4.394a.5.5 0 0 1 .146.353v6.214a.5.5 0 0 1-.146.353l-4.394 4.394a.5.5 0 0 1-.353.146H4.893a.5.5 0 0 1-.353-.146L.146 11.46A.5.5 0 0 1 0 11.107V4.893a.5.5 0 0 1 .146-.353zM5.1 1 1 5.1v5.8L5.1 15h5.8l4.1-4.1V5.1L10.9 1z"/>
                  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
                </svg>
              </button>
            </form>
            <script>
              document.getElementById('eliminar<?php echo $count?>').addEventListener('submit', function(event) {
                let confirmation = confirm('¿Está seguro que quiere dar de baja a <?php echo $externo->Nombre ?>?');
                if (!confirmation) {
                    event.preventDefault(); 
                }
            });
            </script>
      </div>
    </td>
    </tr>
<?php   $count=$count+1;
        } 

  $Internosb = Directores::getInternosb(); 
?>
<?php foreach ($Internosb as $interno) { ?>
    <tr>
      <th scope="row"  class="table-light" ><?php echo $interno->Nombre ?></th>
      <td class="table-secondary"><?php echo $interno->Apellido_p?></td>
      <td  class="table-light" ><?php echo $interno->Apellido_M ?></td>
      <td class="table-secondary">Universidad Veracruzana</td>
      <td class="table-light" >
        <div class="col" style="display: flex;">
            <form id="alta<?php echo $count?>" action="./?action=eliminar_director&" method="post">
              <input type="hidden" name="opt" value="alta">
              <input type="hidden" name="id" value="<?php echo $interno->Id_director; ?>">
              <button class="btn btn-success" type="submit" data-bs-toggle="tooltip" title="Dar de alta  <?php echo $interno->Nombre?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-lg" viewBox="0 0 16 16">
                  <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"/>
                </svg>
              </button>
            </form>
            <script>
              document.getElementById('alta<?php echo $count?>').addEventListener('submit', function(event) {
                let confirmation = confirm('¿Está seguro que quiere dar de alta a <?php echo $interno->Nombre ?>?');
                if (!confirmation) {
                    event.preventDefault(); 
                }
            });
            </script>
            </div>
        </td>
      <!-- <td class="table-light" ><?php echo $interno->Correo ?></td>
      <td class="table-secondary"><?php echo $interno->Num_personal ?></td> -->
    </tr>
<?php $count=$count+1;
  } 

    $Externosb = Directores::getExternosb(); 
    foreach ($Externosb as $externo) { ?>
    <tr>
      <th scope="row" class="table-light" ><?php echo $externo->Nombre ?></th>
      <td class="table-secondary"><?php echo $externo->Apellido_p?></td>
      <td class="table-light" ><?php echo $externo->Apellido_M ?></td>
      <td class="table-secondary"><?php echo $externo->Nombre_Universidad ?></td>
      <!-- <td class="table-light" ><?php echo $externo->Correo ?></td>
      <td class="table-secondary"><?php echo $externo->Num_personal ?></td>
  -->
    <td class="table-light" >
      <div class="col-md" style="display: flex;">
        
        <form id="alta<?php echo $count?>" action="./?action=eliminar_director&" method="post">
              <input type="hidden" name="opt" value="alta">
              <input type="hidden" name="id" value=" <?php echo $externo->Id_director; ?>">
              <button class="btn btn-success" type="submit" data-bs-toggle="tooltip" title="Dar de alta <?php echo $externo->Nombre ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-lg" viewBox="0 0 16 16">
                  <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"/>
              </svg>
              </button>
              
            </form>
            <script>
              document.getElementById('alta<?php echo $count?>').addEventListener('submit', function(event) {
                let confirmation = confirm('¿Está seguro que quiere dar de alta a <?php echo $externo->Nombre ?>?');
                if (!confirmation) {
                    event.preventDefault(); 
                }
            });
            </script>
      </div>
    </td>
    </tr>
<?php   $count=$count+1;
      } ?>
    </tbody>
</table>
<?php }else{ Core::addToastr('warning', "No tienes permiso");
    Core::redir("./?view=index");
    exit; } }else{?>
  incia sesion
  <?php }?>
  <script>
    function filterTable() {
    const searchInput = document.getElementById('search').value.toLowerCase();
    const filterAdscription = document.getElementById('filterAdscricpion').value;
    const rows = document.querySelectorAll('tbody tr');

    rows.forEach(row => {
        const name = row.cells[0].textContent.toLowerCase();
        const lastNameP = row.cells[1].textContent.toLowerCase();
        const lastNameM = row.cells[2].textContent.toLowerCase();
        const adscription = row.cells[3].textContent;

        const matchesSearch = name.includes(searchInput) || lastNameP.includes(searchInput) || lastNameM.includes(searchInput);
        const matchesAdscription = filterAdscription === '' || adscription === filterAdscription;

        if (matchesSearch && matchesAdscription) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

document.getElementById('search').addEventListener('keyup', filterTable);
document.getElementById('filterAdscricpion').addEventListener('change', filterTable);
  </script>