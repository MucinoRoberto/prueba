<?php if(isset($_SESSION["user_id"])){?>
    <nav class="fixed-bottom-left ">
                <a data-bs-toggle="tooltip"  title="Regresar" class="navbar-brand" href="?view=director">
                        <svg width="40" height="40" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
                        </svg>
                </a>
                
        </nav>
<div class="row justify-content-center">
    <div class="col-md-7">
<?php 

if(isset($_POST["opt"]) && $_POST["opt"] == "interno"){
   $Interno=Directores::getInterno($_POST['id']);
   if($Interno->Status==2){
    Core::addToastr('warning', "No se puede editar al usuario");
            echo "<script>window.history.back();</script>";
            exit;
   }
   ?>
   <form action="./?action=actualizar_interno&id=<?php echo $id; ?>" method="post">
   <div class="row ">
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="Nombre" class="form-control" value="<?php echo $Interno->Nombre;?>" id="Nombre" placeholder="Name" >
                <label for="Nombre">Nombre:</label>
            </div>
        </div>
                
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoP" class="form-control" value="<?php echo $Interno->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                <label for="ApellidoP">Apellido Paterno:</label>
            </div>
        </div>
                        
    </div>
    <div class="row ">
        <div class="col-sm-6">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoM" class="form-control" value="<?php echo $Interno->Apellido_M;?>" id="apellidom" placeholder="Apellido">
                <label for="ApellidoM">Apellido Materno:</label>
            </div>
        </div>
      
        <?php 
                $Universidades= Universidades::getUniversidades();?>
                
                    <div class="col-md-6"id="universidades" style="display: none;" >
                        <div class="form-floating">
                            <select  class="form-select"  id="Adscripcion" name="Adscripcion"  placeholder=""  >
                            <option value="0" selected>...</option>
                                <?php foreach ($Universidades as $universidad) { ?>
                                <option value="<?php echo $universidad->Id_Universidad; ?>"><?php echo $universidad->Nombre_Universidad; ?></option>
                                <?php } ?>
                            </select>
                            <label for="Adscripcion">Adscripcion</label>
                        </div>
                    </div>
          
        
    </div>
    
    <div class="row">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" onchange="Universidades()" value="" id="flexCheckChecked" checked>
                <label class="form-check-label" for="flexCheckChecked">
                Interno
                </label>
            <input type="hidden" id="interno" name="Interno" value="1">
        </div>
    </div>
    <br>
    <div class="row ">
            <div class="col-sm">
                    <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
            </div>
            
            
    </div>
    </form>
   <?php
}else if(isset($_POST["opt"]) && $_POST["opt"] == "externo"){
    echo "maestro externo";
    
    $Externo=Directores::getExterno($_POST['id']);
    ?>
    <form action="./?action=actualizar_externo&id=<?php echo $id; ?>" method="post">
    <div class="row ">
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="Nombre" class="form-control" value="<?php echo $Externo->Nombre;?>" id="Nombre" placeholder="Name" >
                <label for="Nombre">Nombre:</label>
            </div>
        </div>
                
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoP" class="form-control" value="<?php echo $Externo->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                <label for="ApellidoP">Apellido Paterno:</label>
            </div>
        </div>
                        
    </div>
    <div class="row ">
        <div class="col-sm-6">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoM" class="form-control" value="<?php echo $Externo->Apellido_M;?>" id="apellidom" placeholder="Apellido">
                <label for="ApellidoM">Apellido Materno:</label>
            </div>
        </div>
      
        <?php 
                $Universidades= Universidades::getUniversidades();?>
                
                    <div class="col-md-6"id="universidades" style="display: block;" >
                        <div class="form-floating">
                            <select  class="form-select"  id="Adscripcion" name="Adscripcion"  placeholder=""  >
                                <?php foreach ($Universidades as $universidad) {
                                    if($universidad->Id_Universidad==$Externo->Id_Universidad){ ?>
                                    
                                <option value="<?php echo $universidad->Id_Universidad; ?>" selected><?php echo $universidad->Nombre_Universidad; ?> </option>
                                <?php } else  {?>
                                    <option value="<?php echo $universidad->Id_Universidad; ?>" ><?php echo $universidad->Nombre_Universidad; ?> </option> 
                                    <?php
                                }
                               } ?>
                            </select>
                            <label for="Adscripcion">Adscripcion</label>
                        </div>
                    </div>
          
        
    </div>
    
    <div class="row">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" onchange="Universidades()" value="" id="flexCheckChecked" >
                <label class="form-check-label" for="flexCheckChecked">
                Interno
                </label>
            <input type="hidden" id="interno" name="Interno" value="0">
        </div>
    </div>
    <br>
    <div class="row">
                <div class="col-sm">
                        <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
                </div>
            
            
         </div>
    </form>
    <?php
 }else{?>
 hola
 <?php }?>

 <script>

function Universidades() {
        var checkbox = document.getElementById('flexCheckChecked');
        var div = document.getElementById('universidades');
        var interno = document.getElementById('interno');
        interno.value = checkbox.checked ? '1' : '0';

        if (checkbox.checked) {
            
            div.style.display = 'none';
        } else {
            
            div.style.display = 'block';
        }

    }

</script>
<?php }else{?>
  incia sesion
  <?php }?>