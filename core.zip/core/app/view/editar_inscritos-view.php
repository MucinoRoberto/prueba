<?php if(isset($_SESSION["user_id"])){?>
        <nav class="fixed-bottom-left ">
                <a data-bs-toggle="tooltip"  title="Regresar" class="navbar-brand" href="?view=inscritos">
                        <svg width="40" height="40" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
                        </svg>
                </a>
                
        </nav>
<div class="row justify-content-center">
    <div class="col-md-7">
<?php 
if(isset($_POST["opt"]) && $_POST["opt"] == "editar"){
    $egresado=Inscritos::getAlumno2($_POST['matricula']);
    $inscrito=Inscritos::getAlumno($_POST['matricula']);
    if($inscrito->Status!=1){
        Core::addToastr('warning', "No se puede editar al alumno");
        echo "<script>window.history.back();</script>";
        exit;
    }
 if($egresado!=null){?>
 
<form action="./?action=actualizar_inscritos&" method="post">
<div class="form-floating mb-3">
        <input type="text" name="Matricula" class="form-control" value="<?php echo $egresado->Matricula;?>" id="Matricula" placeholder="S00000000" disabled>
                <label for="Matricula">Matricula:</label>
        </div>
        <input type="hidden" name="Matricula" class="form-control" value="<?php echo $egresado->Matricula;?>" id="Matricula" placeholder="S00000000" >
     
         <div class="row ">
                 <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="Nombre" class="form-control" value="<?php echo $egresado->Nombre;?>" id="Nombre" placeholder="Name" >
                                <label for="Nombre">Nombre:</label>
                        </div>
                         
                 </div>
                
                 <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="ApellidoP" class="form-control" value="<?php echo $egresado->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                                <label for="ApellidoP">Apellido Paterno:</label>
                        </div>
                         
                 </div>
                        
         </div>
         <div class="row">
                <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="ApellidoM" class="form-control" value="<?php echo $egresado->Apellido_M;?>" id="apellidom" placeholder="Apellido">
                                <label for="ApellidoM">Apellido Materno:</label>
                        </div>
                         
                </div>
                <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="Genero" class="form-control" value="<?php echo $egresado->Genero;?>" id="genero" placeholder="genero" disabled>
                                <label for="Genero">Género:</label>
                        </div>
                         
                </div>
        </div>

        <div class="row">
                <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="date" name="dob" class="form-control" value="<?php echo $egresado->Dob;?>" id="genero" placeholder="genero" >
                                     <label for="dob">Fecha de nacimiento:</label>
                             </div>
                              
                     </div>
             </div>
        <div class="row ">    
                <?php   $Carreras = Consultas::getCarreras(); ?>      
                <div class="col-sm">
                        <div class="form-floating mb-3">
                                <select class="form-select" aria-label="Disabled select example" id="carrera" name="Carrera" required>
                                <?php foreach ($Carreras as $carrera) { if($carrera->Id_carrera==$inscrito->Carrera_fk){?>
                                <option selected value="<?php echo $carrera->Id_carrera; ?>"><?php echo $carrera->Nombre_carrera ?></option><?php }else{?>
                                <option  value="<?php echo $carrera->Id_carrera; ?>"><?php echo $carrera->Nombre_carrera ?>  </option>     
                                <?php } ?>
                                <?php } ?>
                                </select>
                                <label for="movilidad">Carrera</label>
                        </div>
                         
                </div>
                <div class="col-sm-6">
                        <div class="form-floating mb-3">
                                <input type="text" name="Ingreso" class="form-control" value="<?php echo $egresado->fecha?>" id="ingreso" placeholder="ingreso">
                                <label for="Ingreso">Ingreso:</label>
                        </div>
                 </div>
        </div>
                 <div class="row">
                <div class="col-sm">
                        <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
                </div>
                
         </div>
         <?php
 }else{
        echo "hubo un problema";
 }
}
?>
<?php }else{?>
  incia sesion
  <?php }?>