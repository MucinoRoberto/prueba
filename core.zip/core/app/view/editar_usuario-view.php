<?php if(isset($_SESSION["user_id"])){
  
    $id=$_SESSION["user_id"];
    $usuario= Usuarios::getUsuario($id);

    ?>
   
    
    <div class="row justify-content-center">
    <div class="col-md-7">
        
    <?php if(isset($_POST["opt"]) && $_POST["opt"] == "usuario"){
    if($usuario->Tipo==3){ 
    $usuario=Usuarios::getUsuario($_POST['id']);
    if($usuario->Status!=1){
        Core::addToastr('warning', "No se puede editar el usuario");
        echo "<script>window.history.back();</script>";
        exit;
    }
    $tipos=Usuarios::getTipos();
    if($usuario!=null){?>
        <nav class="fixed-bottom-left ">
            <a data-bs-toggle="tooltip"  title="Regresar" class="navbar-brand" href="?view=usuarios">
                <svg width="40" height="40" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
                </svg>
            </a>         
        </nav>

        <form action="./?action=actualizar_usuarios&" method="post">
        <input type="hidden" name="opt" value="usuario">
        <input type="hidden" name="id" value="<?php echo $_POST['id']?>">
                <div class="row ">
                    <div class="col-sm">
                            <div class="form-floating mb-3">
                                    <input type="text" name="Nombre" class="form-control" value="<?php echo $usuario->Nombre;?>" id="Nombre" placeholder="Name" >
                                    <label for="Nombre">Nombre:</label>
                            </div>      
                    </div>
                    
                    <div class="col-sm">
                            <div class="form-floating mb-3">
                                    <input type="text" name="ApellidoP" class="form-control" value="<?php echo $usuario->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                                    <label for="ApellidoP">Apellido Paterno:</label>
                            </div>
                    </div>
                            
                </div>
            

            <div class="row">
                     <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="ApellidoM" class="form-control" value="<?php echo $usuario->Apellido_m;?>" id="apellidom" placeholder="Apellido" >
                                     <label for="ApellidoM">Apellido Materno:</label>
                             </div>
                              
                     </div>
                     <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="user" class="form-control" value="<?php echo $usuario->Nombre_Usuario;?>" id="usuario" placeholder="Nombre de usuario" >
                                     <label for="user">Nombre de usuario:</label>
                             </div>
                              
                     </div>
             </div>
             <div class="row">
                     <div class="col-sm-6">
                        <div class="form-floating mb-3">
                                <select class="form-select" aria-label="Disabled select example" id="Rango" name="Rango" required>
                                <?php foreach ($tipos as $tipo) { 
                                    if($tipo->Id_tipo==$usuario->Tipo){?>
                                    <option selected value="<?php echo $tipo->Id_tipo; ?>"><?php echo $tipo->Tipo ?></option>
                                    <?php }else{?>
                                    <option  value="<?php echo $tipo->Id_tipo; ?>"><?php echo $tipo->Tipo ?>  </option>     
                                    <?php } ?>
                                <?php } ?>
                                </select>
                                <label for="Rango">Rango</label>
                        </div>      
                     </div>
             </div>
             <div class="row align-items-center">
                <div class="col-sm">
                    <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
                </div>

             </div>

        </form>
        
 <?php }else{
        echo "Usuario no encontrado";
  }
   }else{ 
    Core::addToastr('warning', "No tienes permiso");
      Core::redir("./?view=index");
      exit; } 
    }else { 
    $usuario=Usuarios::getUsuario($_SESSION["user_id"]);
    $tipos=Usuarios::getTipos();
    if($usuario!=null){
        if($usuario->Tipo==3){?>
        <nav class="fixed-bottom-left ">
            <a data-bs-toggle="tooltip"  title="Regresar" class="navbar-brand" href="?view=usuarios">
                <svg width="40" height="40" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                    <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
                </svg>
            </a>         
        </nav>
        <?php }?>
        <form id="password" action="./?action=actualizar_usuarios&" method="post">
            <input type="hidden" name="opt" value="propio">

            <div class="row">
                <div class="col-sm">
                    <div class="form-floating mb-3">
                        <input type="text" name="Nombre" class="form-control" value="<?php echo $usuario->Nombre;?>" id="Nombre" placeholder="Name">
                        <label for="Nombre">Nombre:</label>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="form-floating mb-3">
                        <input type="text" name="ApellidoP" class="form-control" value="<?php echo $usuario->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                        <label for="ApellidoP">Apellido Paterno:</label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm">
                    <div class="form-floating mb-3">
                        <input type="text" name="ApellidoM" class="form-control" value="<?php echo $usuario->Apellido_m;?>" id="apellidom" placeholder="Apellido">
                        <label for="ApellidoM">Apellido Materno:</label>
                    </div>
                </div>
                <div class="col-sm">
                    <div class="form-floating mb-3">
                        <input type="text" name="user" class="form-control" value="<?php echo $usuario->Nombre_Usuario;?>" id="usuario" placeholder="Nombre de usuario">
                        <label for="user">Nombre de usuario:</label>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-6" id="editar" style="display: block;">
                    <button type="button" class="btn btn-outline-secondary" onclick="EditarContraseña()" id="agregarcorreo">Editar contraseña</button>
                </div>
            </div>

            <div class="row" id="contra" style="display: none;">
                <small>Inserta tu contraseña actual</small>
                <div class="col-sm">
                    <div class="form-floating mb-3">
                        <input type="password" name="contra" class="form-control" id="contraActual" placeholder="Contraseña actual" disabled>
                        <label for="contra">Contraseña actual</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6" id="contranueva" style="display: none;">
                    <div class="form-floating mb-3">
                        <input type="password" name="contranueva" class="form-control" id="newPassword" placeholder="Nueva contraseña" disabled>
                        <label for="contranueva">Contraseña nueva</label>
                    </div>
                </div>
                <div class="col-sm-6" id="contranueva2" style="display: none;">
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="confirmPassword" placeholder="Repetir contraseña" disabled>
                        <label for="contranueva2">Repetir contraseña</label>
                    </div>
                </div>
            </div>
            
            <br>
            
            <div class="row">
                <div class="col-sm">
                    <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
                </div>
            </div>
        </form>
        <script>
        document.getElementById('password').addEventListener('submit', function(event) {
        const currentPassword = document.getElementById('contraActual').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (currentPassword === "" && newPassword !== "") {
            toastr.warning('Ingresa tu contraseña actual.');
            event.preventDefault();
        } else if (newPassword === "" && confirmPassword === "" && currentPassword !== "") {
            toastr.warning('Ingresa la contraseña nueva.');
            event.preventDefault();
        } else if (newPassword !== confirmPassword) {
            toastr.warning('Las contraseñas nuevas no coinciden.');
            event.preventDefault();
        }
    });
        </script>
 <?php }else{
        echo "Usuario no encontrado";
  } 
    }?>

<?php }else{?>
 Inicia sesion
 <?php }?>

 <script>

document.getElementById('Rango').addEventListener('change', function() {
        if (this.value == '3') {
            let confirmation = confirm('¿Está seguro que quiere hacer super administrador a este usuario?');
            if (!confirmation) {
                this.value = '<?php echo $usuario->Tipo;?>'; 
            }
        }
    });

    function EditarContraseña() {
        document.getElementById("contra").style.display = "block";
        document.getElementById("contranueva").style.display = "block";
        document.getElementById("contranueva2").style.display = "block";
        document.getElementById("editar").style.display = "none";

        document.getElementById('contraActual').disabled = false;
        document.getElementById('newPassword').disabled = false;
        document.getElementById('confirmPassword').disabled = false;
    }

   
    </script>