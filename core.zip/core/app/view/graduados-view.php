<style>
    
    .full-height-image {
    width: 100%;
    height: 100vh; 
    object-fit: cover; 
    padding: 0px;
}

</style>

    <img  src="core/app/layouts/graduados.jpg" class="img-fluid full-height-image">