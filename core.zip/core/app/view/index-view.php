<?php if(isset($_SESSION["user_id"])){?>
Bienvenido ^.^
<?php }else{?>
  incia sesion
  <?php }?>