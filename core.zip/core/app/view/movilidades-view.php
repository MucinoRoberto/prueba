<?php if(isset($_SESSION["user_id"])){
   $id=$_SESSION["user_id"];
   $usuario= Usuarios::getUsuario($id);
  if($usuario->Tipo==3){?>

<div class="form-section">
  <div class="row">
    <div class="col-md">
      <input type="text" id="search" placeholder="Buscar..." class="form-control mb-3" onkeyup="filterTable()">
    </div>
    <div class="col-md">
      <select id="filterStatus" class="form-select" onchange="filterTable()">
        <option value="">Todos los estados</option>
        <option value="1">Activo</option>
        <option value="2">Inactivo</option>
      </select>
    </div>
  </div>

  <table id="movilidadesTable" class="table">
    <thead>
      <tr class="table-light">
        <th scope="col">Dependencia</th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      <?php $Movilidades = Movilidades::getMovilidadesS(); ?>
      <?php foreach ($Movilidades as $movilidad) {
        if ($movilidad->Id_movilidad != 1) { ?>
        <tr data-status="<?php echo $movilidad->Status; ?>">
          <th scope="row" class="table-light"><?php echo $movilidad->Dependencia; ?></th>
          <td class="table-secondary">
            <?php if($movilidad->Status == 1){ ?>
              <form id="eliminar<?php echo $count; ?>" action="./?action=eliminar_movilidad&" method="post">
                <input type="hidden" name="opt" value="eliminar">
                <input type="hidden" name="id" value="<?php echo $movilidad->Id_movilidad; ?>">
                <button class="btn btn-danger" type="submit" data-bs-toggle="tooltip" title="Eliminar <?php echo $movilidad->Dependencia; ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-octagon" viewBox="0 0 16 16">
                  <path d="M4.54.146A.5.5 0 0 1 4.893 0h6.214a.5.5 0 0 1 .353.146l4.394 4.394a.5.5 0 0 1 .146.353v6.214a.5.5 0 0 1-.146.353l-4.394 4.394a.5.5 0 0 1-.353.146H4.893a.5.5 0 0 1-.353-.146L.146 11.46A.5.5 0 0 1 0 11.107V4.893a.5.5 0 0 1 .146-.353zM5.1 1 1 5.1v5.8L5.1 15h5.8l4.1-4.1V5.1L10.9 1z"/>
                  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
                </svg>
                </button>
              </form>
            <?php } else if($movilidad->Status == 2){ ?>
              <form id="alta<?php echo $count; ?>" action="./?action=eliminar_movilidad&" method="post">
                <input type="hidden" name="opt" value="alta">
                <input type="hidden" name="id" value="<?php echo $movilidad->Id_movilidad; ?>">
                <button class="btn btn-success" type="submit" data-bs-toggle="tooltip" title="Dar de alta <?php echo $movilidad->Dependencia; ?>">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-lg" viewBox="0 0 16 16">
                    <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"/>
                  </svg>
                </button>
              </form>
            <?php } ?>
          </td>
        </tr>
      <?php }
      } ?>
    </tbody>
  </table>
</div>

<script>
function filterTable() {
    let searchInput = document.getElementById("search").value.toLowerCase();
    let statusFilter = document.getElementById("filterStatus").value;
    let table = document.getElementById("movilidadesTable");
    let rows = table.getElementsByTagName("tr");

    for (let i = 1; i < rows.length; i++) {
        let dependencia = rows[i].getElementsByTagName("th")[0].innerText.toLowerCase();
        let status = rows[i].getAttribute("data-status");

        let matchesSearch = dependencia.indexOf(searchInput) > -1;
        let matchesStatus = !statusFilter || status === statusFilter;

        rows[i].style.display = matchesSearch && matchesStatus ? "" : "none";
    }
}
</script>

<?php } else { 
    Core::addToastr('warning', "No tienes permiso");
    Core::redir("./?view=index");
    exit; 
} } else { ?>
  inicia sesión
<?php } ?>
