<?php if(isset($_SESSION["user_id"])){
  
  $id=$_SESSION["user_id"];
  $usuario= Usuarios::getUsuario($id);
 if($usuario->Tipo==3){?>
<div class="row">
    <!-- Campo de búsqueda -->
      <div class="col-md">
      <input type="text" id="search" placeholder="Buscar..." class="form-control mb-3" onkeyup="filterTable()">
      </div>
            
    <?php   
        $Rangos = Usuarios::getTipos(); ?>  
        <div class="col-md">
        <select id="filterTitulacion" class="form-select" onchange="filterTable()">
        <option value="">Sin filtro de rangos</option>
                <?php foreach ($Rangos as $rango) { 
                  if($rango->Id_tipo!=3){?>
                    <option value="<?php echo $rango->Tipo; ?>">
                        <?php echo $rango->Tipo; ?>
                    </option>
                <?php } }?>
            </select>
        </div>

  </div>
<table class="table">
  <thead>
    <tr class="table-light">
      <th scope="col">Nombre</th>
      <!-- <th scope="col">Pais</th> -->
      <th scope="col">Apellido Paterno</th>
      <th scope="col">Apellido Materno</th>
      <th scope="col">Rango</th>
      <th scope="col">Nombre de usuario</th>
      <th scope="col">Editar</th>
    </tr>
  </thead>
  <?php $Usuarios=Usuarios::getUsuarios();?>
  
  <tbody>
  <tr>
      <th scope="row"  class="table-light"><?php echo $usuario->Nombre?></th>
      <td class="table-secondary"><?php echo $usuario->Apellido_p?></td>
      <td class="table-light"><?php echo $usuario->Apellido_m?></td>
      <td class="table-secondary"><?php echo $usuario->Tipo_nombre?></td>
      <td class="table-light"><?php echo $usuario->Nombre_Usuario?></td>
      <td class="table-secondary">
        <div class="col">
          <div style="display: flex;">
            <div class="col-md-3">
              <form action="./?view=editar_usuario&" method="post" style="margin-right: 10px;">
                <input type="hidden" name="opt" value="propio">
                <button class="btn btn-primary" type="submit" data-bs-toggle="tooltip" title="Editar <?php echo $usuario->Nombre_Usuario?>">
                  <svg xmlns="http://www.w3.org/2000/svg"  href="?view=agregar_inscritos" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                  </svg>
                </button>
              </form>
            </div>
          </div>
        </div>  
      </td>
    </tr>
    <?php $count=0;
    foreach($Usuarios as $user){?>
        <?php if ($user->ID_usuario!=$id && $user->Tipo!=3){?>
    <tr>
      <th scope="row"  class="table-light"><?php echo $user->Nombre?></th>
      <td class="table-secondary"><?php echo $user->Apellido_p?></td>
      <td class="table-light"><?php echo $user->Apellido_m?></td>
      <td class="table-secondary"><?php echo $user->Tipo_nombre?></td>
      <td class="table-light"><?php echo $user->Nombre_Usuario?></td>
      <td class="table-secondary">
        <div class="col">
          <div style="display: flex;">
            <div class="col-md-3" style="display: flex;">
            <?php if ($user->Status==1){?>
            <form action="./?view=editar_usuario&" method="post" style="margin-right: 10px;">
              <input type="hidden" name="opt" value="usuario">
              <input type="hidden" name="id" value="<?php echo $user->ID_usuario?>">
              <button class="btn btn-primary" type="submit" data-bs-toggle="tooltip" title="Editar <?php echo $user->Nombre_Usuario?>">
                <svg xmlns="http://www.w3.org/2000/svg"  href="?view=agregar_inscritos" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                </svg>
              </button>
            </form>
          
            <form id="eliminar<?php echo $count?>" action="./?action=eliminar_usuario&" method="post" >
              <input type="hidden" name="opt" value="eliminar">
              <input type="hidden" name="id" value="<?php echo $user->ID_usuario?>">
              <button class="btn btn-danger" type="submit" data-bs-toggle="tooltip" title="Eliminar <?php echo $user->Nombre_Usuario?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-octagon" viewBox="0 0 16 16">
                  <path d="M4.54.146A.5.5 0 0 1 4.893 0h6.214a.5.5 0 0 1 .353.146l4.394 4.394a.5.5 0 0 1 .146.353v6.214a.5.5 0 0 1-.146.353l-4.394 4.394a.5.5 0 0 1-.353.146H4.893a.5.5 0 0 1-.353-.146L.146 11.46A.5.5 0 0 1 0 11.107V4.893a.5.5 0 0 1 .146-.353zM5.1 1 1 5.1v5.8L5.1 15h5.8l4.1-4.1V5.1L10.9 1z"/>
                  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
                </svg>
              </button>
            </form>
            <script>
               document.getElementById('eliminar<?php echo $count?>').addEventListener('submit', function(event) {
                    let confirmation = confirm('¿Está seguro que quiere dar de baja a <?php echo $user->Nombre_Usuario?>?');
                    if (!confirmation) {
                        event.preventDefault(); 
                    }
                });
            </script>
            <?php } else if ($user->Status==2){?>
            <form id="alta<?php echo $count?>" action="./?action=eliminar_usuario&" method="post" >
              <input type="hidden" name="opt" value="alta">
              <input type="hidden" name="id" value="<?php echo $user->ID_usuario?>">
              <button class="btn btn-success" type="submit" data-bs-toggle="tooltip" title="Dar de alta ">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-lg" viewBox="0 0 16 16">
                  <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"/>
                </svg>
              </button>
            </form>
            <script>
               document.getElementById('alta<?php echo $count?>').addEventListener('submit', function(event) {
                    let confirmation = confirm('¿Está seguro que quiere dar de baja a <?php echo $user->Nombre_Usuario?>?');
                    if (!confirmation) {
                        event.preventDefault(); 
                    }
                });
            </script>
            <?php }?>
            </div>
          </div>
        </div>  
      </td>
    </tr>
    <?php }
  $count=$count+1;
  }?>
  </tbody>
</table>

<?php }else{ 
 Core::addToastr('warning', "No tienes permiso");
   Core::redir("./?view=index");
   exit; } }else{?>
 Inicia sesion
 <?php }?>
 <script>
  document.getElementById('eliminar').addEventListener('submit', function(event) {
        let confirmation = confirm('¿Está seguro que quiere dar de baja a este usuario?');
        if (!confirmation) {
            event.preventDefault(); 
        }
    });

 </script>
 <script>
function filterTable() {
    var searchInput = document.getElementById('search').value.toLowerCase();
    var filterTitulacion = document.getElementById('filterTitulacion').value.toLowerCase();
    
    var table = document.querySelector('.table');
    var rows = table.querySelectorAll('tbody tr');
    
   
    rows.forEach(function(row) {
      
        var cells = row.querySelectorAll('td, th');
        var match = false;

        cells.forEach(function(cell) {
            if (cell.textContent.toLowerCase().includes(searchInput)) {
                match = true;
            }
        });

        var rangoCell = row.querySelector('td:nth-child(4)');
        if (filterTitulacion && rangoCell) {
            var rangoText = rangoCell.textContent.toLowerCase();
            if (rangoText.includes(filterTitulacion)) {
                match = match && true;
            } else {
                match = false;
            }
        }

        if (match) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>
