<?php

include "controller/Core.php";
include "controller/View.php";
//include "controller/Module.php"; // Renamed to Layout
include "controller/Database.php";
include "controller/Executor.php";

// 10 octubre 2014
include "controller/Lb.php";
include "controller/Model.php";
include "controller/Bootload.php";
include "controller/Action.php";


// 6 Agosto 2022
include "controller/Extra.php";
include "controller/Layout.php";
// 8 Agosto 2022
include "controller/FormTool.php";
include "controller/TableTool.php";

?>