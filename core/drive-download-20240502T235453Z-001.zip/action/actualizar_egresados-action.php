<?php

$egresado = new Egresados();
$alumno=new Inscritos();
$actualizar=new Updates();

$matricula = $_POST['Matricula'];
$Nombre = $_POST['Nombre'];
$ApellidoP = $_POST['ApellidoP'];
$ApellidoM = $_POST['ApellidoM'];
$Carrera = $_POST['Carrera'];
$Area = $_POST['area'];
$Periodo = $_POST['periodo'];
$Ingreso = $_POST['Ingreso'];
$Egreso = $_POST['Egreso'];
$Trabajo = $_POST['Trabajo'];
$Movilidad = $_POST['movilidad'];
$DOB = $_POST['dob'];

$Director1= $_POST['director1'] ?? '';
$Director2= $_POST['director2'] ?? '';


$Telefono1 = $_POST['Telefono1'] ?? '';
$Telefono2 = $_POST['Telefono2'] ?? '';
$TelefonoNuevo1 = $_POST['TelefonoNuevo1'] ?? '';
$TelefonoNuevo2 = $_POST['TelefonoNuevo2'] ?? '';
$TelefonoViejo1=$_POST['telefonoviejo1'] ?? '';
$TelefonoViejo2=$_POST['telefonoviejo2'] ?? '';
$IdTelefonoViejo1=$_POST['idtelefonoviejo1'] ?? '';
$IdTelefonoViejo2=$_POST['idtelefonoviejo2'] ?? '';

$Correo1 = $_POST['Correo1'] ?? '';
$Correo2 = $_POST['Correo2'] ?? '';
$CorreoViejo1 = $_POST['correoviejo1'] ?? '';
$CorreoViejo2 = $_POST['correoviejo2'] ?? '';
$IdCorreoViejo1 = $_POST['idcorreoviejo1'] ?? '';
$IdCorreoViejo2 = $_POST['idcorreoviejo2'] ?? '';
$CorreoNuevo1 = $_POST['CorreoNuevo1'] ?? '';
$CorreoNuevo2 = $_POST['CorreoNuevo2'] ?? '';

$datos_egresado=$egresado->getEgresado($matricula);


if($datos_egresado->Dob!=$DOB){
    $actualizar->UpdateDob($matricula,$DOB);
    Core::addToastr('success', "Fecha de nacimiento actualizada correctamente");
}

if ($datos_egresado->egreso != $Egreso) {
    $actualizar->UpdateEgreso($matricula, $Egreso, $Periodo);
    Core::addToastr('success', "Fecha de egreso actualizada correctamente");
}

if ($datos_egresado->ingreso != $Ingreso) {
    $actualizar->UpdateIngreso($Ingreso, $matricula);
    Core::addToastr('success', "Fecha de ingreso actualizada correctamente");
}

if ($datos_egresado->Nombre != $Nombre) {
    $actualizar->UpdateNombre($Nombre, $matricula);
    Core::addToastr('success', "Nombre actualizado correctamente");
}

if ($datos_egresado->Apellido_p != $ApellidoP) {
    $actualizar->UpdateApellidoP($ApellidoP, $matricula);
    Core::addToastr('success', "Apellido paterno actualizado correctamente");
}

if ($datos_egresado->Apellido_M != $ApellidoM) {
    $actualizar->UpdateApellidoM($ApellidoM, $matricula);
    Core::addToastr('success', "Apellido materno actualizado correctamente");
}

if ($datos_egresado->Periodo != $Periodo) {
    $actualizar->UpdatePeriodo($matricula, $Periodo);
    Core::addToastr('success', "Periodo actualizado correctamente");
}

if ($datos_egresado->Id_movilidad != $Movilidad) {
    $actualizar->UpdateMovilidad($matricula, $Movilidad);
    Core::addToastr('success', "Movilidad actualizada correctamente");
}

if ($datos_egresado->Area != $Area) {
    $actualizar->UpdateArea($matricula, $Area);
    Core::addToastr('success', "Área de desarrollo actualizada correctamente");
}

if ($datos_egresado->Primer_trabajo != $Trabajo) {
    $actualizar->UpdateTrabajo($matricula, $Trabajo);
    Core::addToastr('success', "Primer trabajo actualizado correctamente");
}

if ($datos_egresado->Carrera_fk != $Carrera) {
    $actualizar->UpdateCarrera($matricula, $Carrera);
    Core::addToastr('success', "Carrera actualizada correctamente");
}



if(!empty($Director1)){
$egresado->UpdateDirector($Director1,$matricula,1);
}

if(!empty($Director2)){
    $egresado->UpdateDirector($Director2,$matricula,2);

}


if (!empty($Telefono1) && $Telefono1 !== $TelefonoViejo1){
$egresado->UpdateTelefono($Telefono1,$IdTelefonoViejo1);
Core::addToastr('success', "Telefono actualizado correctamente");
}

if (!empty($Telefono2) && $Telefono2 !== $TelefonoViejo2){
$egresado->UpdateTelefono($Telefono2,$IdTelefonoViejo2);
Core::addToastr('success', "Telefono actualizado correctamente");
}

if(!empty($TelefonoNuevo1) && (empty($Telefono1) && empty($Telefono2) )){
    $egresado->setTelefono($matricula,$TelefonoNuevo1);
    Core::addToastr('success', "Telefono agregado correctamente");
}

if(!empty($TelefonoNuevo2) && (empty($Telefono2) )){
    $egresado->setTelefono($matricula,$TelefonoNuevo2);
    Core::addToastr('success', "Telefono agregado correctamente");
}


if (!empty($Telefono1) && !empty($TelefonoNuevo1)){
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Telefono2) && !empty($TelefonoNuevo2) ){
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Telefono2) && !empty($TelefonoNuevo1) ){
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($TelefonoViejo1) && empty($Telefono1)){
    $egresado->DeleteTelefono($IdTelefonoViejo1);
    Core::addToastr('success', "Telefono eliminado correctamente");
}

if (!empty($TelefonoViejo2) && empty($Telefono2)){
    $egresado->DeleteTelefono($IdTelefonoViejo2);
    Core::addToastr('success', "Telefono eliminado correctamente");
}




if (!empty($Correo1) && $Correo1 !== $CorreoViejo1) {
    $egresado->UpdateCorreo($Correo1,$IdCorreoViejo1);
    Core::addToastr('success', "Correo actualizado correctamente");
}

if (!empty($Correo2) && $Correo2 !== $CorreoViejo2) {
    $egresado->UpdateCorreo($Correo2, $IdCorreoViejo2);
    Core::addToastr('success', "Correo actualizado correctamente");
}

if (!empty($Correo1) && !empty($CorreoNuevo1)) {
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Correo2) && !empty($CorreoNuevo2)) {
    Core::addToastr('warning', "Error en los datos");
}

if (!empty($Correo2) && !empty($CorreoNuevo1)) {
    Core::addToastr('warning', "Error en los datos");
}

if (empty($Correo1) && !empty($CorreoViejo1)) {
    $egresado->DeleteCorreo( $IdCorreoViejo1);
    Core::addToastr('success', "Correo eliminado correctamente");
}

if (empty($Correo2) && !empty($CorreoViejo2)) {
    $egresado->DeleteCorreo($IdCorreoViejo2);
    Core::addToastr('success', "Correo eliminado correctamente");
}

if (!empty($CorreoNuevo1) && empty($Correo1) && empty($Correo2)) {
    $egresado->setCorreo($matricula, $CorreoNuevo1);
    Core::addToastr('success', "Correo agregado correctamente");
}

if (!empty($CorreoNuevo2) && empty($Correo2)) {
    $egresado->setCorreo($matricula, $CorreoNuevo2);
    Core::addToastr('success', "Correo agregado correctamente");
}




?>

<form id="detalles" action="./?view=editar_egresado&" method="post" >     
    <input type="hidden" name="opt" value="detail">
    <input type="hidden" name="matricula" value="<?php echo $matricula ?>">    
</form>

<script>

    window.onload = function() {
        document.getElementById('detalles').submit(); 
    };

</script>