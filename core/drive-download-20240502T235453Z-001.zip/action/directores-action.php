<?php
$director=new Directores();
$Num = $_POST['Num'] ?? '';
$Nombre=$_POST['Nombre'] ?? '';
$ApellidoP=$_POST['ApellidoP'] ?? '';
$ApellidoM=$_POST['ApellidoM'] ?? '';
$Interno=$_POST['Interno'] ?? '';
$Adscripcion=$_POST['Adscripcion'] ?? '';
$Telefono=$_POST['Telefono'] ?? '';
$Correo=$_POST['Correo'] ?? '';

if($Interno==1){
$success=$director->setDirectorInterno($Nombre,$ApellidoP,$ApellidoM,$Correo,$Num);
}else if($Interno==0){
    $success=$director->setDirectorExterno($Nombre,$ApellidoP,$ApellidoM,$Adscripcion,$Correo,$Num);
}
if($success!=null){
    Core::addToastr('success',"Agregado correctamente");
    Core::redir("?view=director");
    exit;
}else if($success==null) {
    Core::addToastr('warning', "Hubo un problema");
    echo "<script>window.history.back();</script>";
    exit;
}
Core::addToastr('warning', "Hubo un problema");
echo "<script>window.history.back();</script>";
exit;
