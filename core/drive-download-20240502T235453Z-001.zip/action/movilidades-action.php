<?php
$movilidades=new Movilidades();
$Dependencia=$_POST['dependencia'];
$Pais=$_POST['Pais'];

$verificar=$movilidades->VerificarDependencia($Dependencia);
if($verificar==null){
Core::addToastr('warning',"Hubo un problema desconocido");
    echo "<script>window.history.back();</script>";
    exit;
}else if($verificar->count==0){
    $agregar=$movilidades->setMovilidad($Dependencia,$Pais);
    if($agregar==null){
        Core::addToastr('warning',"Hubo un problema al agregar la dependencia");
        echo "<script>window.history.back();</script>";
        exit;
    }else{
        Core::addToastr('success',"Agregado correctamente");
        Core::redir("?view=movilidades");
        exit;
    }
}else if($verificar->count>0){
    Core::addToastr('warning',"La dependecia ya existe");
    echo "<script>window.history.back();</script>";
    exit;

} 