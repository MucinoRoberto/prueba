<?php

class Consultas extends Extra
{
	public static function getByID($id)
	{
		$sql = "select * from c_usuarios where id=" . $id;
		$query = Executor::doit($sql);
		return Model::one($query[0], new Consultas());
	}

	public static function getDirectores(){
		$sql = "select * from seguimiento_egresados2.directorest;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
	}
    
    public static function getMovilidades(){
        $sql = "select * FROM seguimiento_egresados2.movilidades;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

    public static function getAreaDesarrollo(){
        $sql = "select * FROM seguimiento_egresados2.areas_desarrollo;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

	public static function getTitulaciones(){
        $sql = "select * from seguimiento_egresados2.titulaciones;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }
    public static function getMatriculas(){
        $sql = "select * from seguimiento_egresados2.alumnos_inscritos where Status=1;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    } 

	public static function getCarreras(){
        $sql = "SELECT * FROM seguimiento_egresados2.carreras;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

	public static function getUniversidades(){
        $sql = "SELECT * FROM seguimiento_egresados2.universidades;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

	public static function getFacultades(){
        $sql = "SELECT * FROM seguimiento_egresados2.facultades;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

	public static function getGeneros(){
        $sql = "select * from generos;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    } 
	


}
