<?php
class Directores extends Extra
{
public function setDirectorExterno($nombre,$apellidop,$apellidom,$adscripcion,$correo,$num){
    try{
        $sql = "INSERT INTO `seguimiento_egresados2`.`directorest` (`Nombre`, `Apellido_p`, `Apellido_M`, `Adscripcion_fk`, `Interno`, `Correo`, `Num_personal`) VALUES ('$nombre', '$apellidop', '$apellidom', '$adscripcion', '0', '$correo', '$num');";
        return Executor::doit($sql);
    }catch(Exception){
        return null;
    }
    }

    public function setDirectorInterno($nombre,$apellidop,$apellidom,$correo,$num){
        try{
            $sql = "INSERT INTO `seguimiento_egresados2`.`directorest` (`Nombre`, `Apellido_p`, `Apellido_M`, `Interno`, `Correo`, `Num_personal`) VALUES ('$nombre', '$apellidop', '$apellidom', '1', '$correo', '$num');";
            return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
        }

    public static function getExterno($director){
        $sql = "SELECT * FROM seguimiento_egresados2.directores_externos where Id_director='$director' ;";
        $query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
    }

    public static function getExternos(){
        $sql = "SELECT * FROM seguimiento_egresados2.directores_externos ;";
        $query = Executor::doit($sql);
        return Model::many($query[0], new Consultas());
    }

    
    public static function getInternos(){
        $sql = "SELECT * FROM directorest where Interno=1;";
        $query = Executor::doit($sql);
        return Model::many($query[0], new Consultas());
    }

    public static function getInterno($id){
        $sql = "SELECT * FROM directorest where Id_director='$id';";
        $query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
    }

}