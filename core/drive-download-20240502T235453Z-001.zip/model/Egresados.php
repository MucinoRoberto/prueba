<?php
class Egresados extends Extra
{
    
    public function setEgresado($matricula, $metodo ,$egreso, $periodo, $trabajo,$posgrado, $movilidad, $area)
    {
        if ($periodo == 1) {
            $titulacion = date('Y-m-d', strtotime($egreso . "-01-31"));
        } else {
            $titulacion = date('Y-m-d', strtotime($egreso . "-07-31"));
        }

      
    
        $sql = "INSERT INTO egresados (Matricula, Metodo_titulacion_fk ,Posgrado ,Primer_trabajo, Movilidad_fk, Area_desarrollo_fk, Periodo,Fecha_Egreso) VALUES ('$matricula',$metodo,$posgrado,'$trabajo', $movilidad, $area, $periodo,'$titulacion')";
        return Executor::doit($sql);
    }
    
    public function setDirector($matricula,$director){
        $sql = "INSERT INTO alumno_director (Alumno_fk, Director_fk, Tipo_director) VALUES ('$matricula',$director,1)";
        return Executor::doit($sql);
    }

    public function setCoodirector($matricula,$director){
        $sql = "INSERT INTO alumno_director (Alumno_fk, Director_fk,Tipo_director) VALUES ('$matricula',$director,2)";
        return Executor::doit($sql);
    }

    public function setTelefono($matricula,$telefono){
        $sql = "INSERT INTO `seguimiento_egresados2`.`telefonos` (`Num_telefono`, `Egresado_fk`,`Status`) VALUES ('$telefono', '$matricula','1');";
        return Executor::doit($sql);
    }

    public function UpdateEgresado($matricula,$egreso,$periodo,$trabajo,$movilidad,$area){
        if ($periodo == 1) {
            $titulacion = date('Y-m-d', strtotime($egreso . "-01-31"));
        } else {
            $titulacion = date('Y-m-d', strtotime($egreso . "-07-31"));
        }
    
        $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Fecha_Egreso` = '$titulacion', `Periodo` = '$periodo',  `Primer_trabajo` = '$trabajo', `Movilidad_fk` = '$movilidad', `Area_desarrollo_fk` = '$area' WHERE (`Matricula` = '$matricula');";
        return Executor::doit($sql);
    }

    public function UpdateTelefono($telefono,$idtelefonoviejo){
        $sql = "UPDATE `seguimiento_egresados2`.`telefonos` SET `Num_telefono` = '$telefono' WHERE (`Id_telefono` = '$idtelefonoviejo'  );";
        return Executor::doit($sql);
    }

    public function DeleteTelefono($idtelefonoviejo){
        $sql = "UPDATE `seguimiento_egresados2`.`telefonos` SET `Status` = '2' WHERE (`Id_telefono` = '$idtelefonoviejo' );";
        return Executor::doit($sql);
    }

    public function DeleteCorreo($idcorreo){
        $sql = "UPDATE `seguimiento_egresados2`.`correos` SET `Status` = '2' WHERE (`Id_correos` = '$idcorreo' );";
        return Executor::doit($sql);
    }
    public function UpdateCorreo($correo,$idcorreo){
        $sql = "UPDATE `seguimiento_egresados2`.`correos` SET `Correo` = '$correo' WHERE(`Id_correos` = '$idcorreo');";
        return Executor::doit($sql);
    }
    
    public function UpdateDirector($director,$matricula,$tipo){
        $sql = "UPDATE `seguimiento_egresados2`.`alumno_director` SET `Director_fk` = '$director' WHERE (`Alumno_fk` = '$matricula' and `Tipo_director` = '$tipo');";
        return Executor::doit($sql);
    }

    public function setCorreo($matricula,$correo){
        $sql = "INSERT INTO `seguimiento_egresados2`.`correos` (`Correo`, `Egresado_fk`, `Status`) VALUES ('$correo', '$matricula', '1');";
        return Executor::doit($sql);
    }
    
    public static function getDatos(){
        $sql = "SELECT * FROM seguimiento_egresados2.datos_egresados order by Matricula;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

    public static function getEgresado($matricula){
        try{
        $sql = "SELECT * FROM seguimiento_egresados2.datos_egresados where matricula='$matricula';";
		$query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
        }catch(Exception){
            return null;
        }
    }

    public static function verificar($matricula){

        $sql = "SELECT count(Matricula) as count FROM seguimiento_egresados2.egresados where Matricula='$matricula';";
		$query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());

    }
   
    public static function getTotalTelefonos($matricula){
        $sql = "SELECT count(*) as total  FROM seguimiento_egresados2.telefonos where Egresado_fk='$matricula' and Status=1;";
		$query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
    }

    public static function getTotalCorreos($matricula){
        $sql = "SELECT count(*) as total  FROM seguimiento_egresados2.correos where Egresado_fk='$matricula' and Status=1;";
		$query = Executor::doit($sql);
        return Model::one($query[0], new Consultas());
    }

    public static function getDirectores($matricula){
        $sql = "SELECT t.Tipo,ad.Id_aludir,d.Id_director,d.Interno , d.Nombre, d.Apellido_p, d.Apellido_M FROM tipo_directores t,alumno_director ad, directorest d where ad.Director_fk= d.Id_director and t.Id_tipo=ad.Tipo_director and Alumno_fk='$matricula';";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

    public static function getCountDirectores($matricula){
        $sql = "SELECT count(*) as count FROM tipo_directores t,alumno_director ad, directorest d where ad.Director_fk= d.Id_director and t.Id_tipo=ad.Tipo_director and Alumno_fk='$matricula';";
		$query = Executor::doit($sql);
		return Model::one($query[0], new Consultas());
    }

    public static function getTelefonos($matricula){
        $sql = "SELECT * FROM telefonos where Egresado_fk='$matricula' and Status=1;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }

    public static function getCorreo($matricula){
        $sql = "SELECT * FROM seguimiento_egresados2.correos where Egresado_fk='$matricula' and Status=1;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }
}
