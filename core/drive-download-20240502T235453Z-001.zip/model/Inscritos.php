<?php
class Inscritos extends Extra
{

    
    public function setInscrito($matricula, $nombre, $apellidop, $apellidom, $dob, $genero, $anio){
        $ingreso = date('Y-m-d', strtotime($anio . "-08-01"));
        $sql = "INSERT INTO alumnos_inscritos (Matricula, Nombre, Apellido_p, Apellido_M, Genero_fk, Carrera_fk, Nivel_fk, Facultad_fk, Fecha_Ingreso, Status  ) VALUES ('$matricula', '$nombre', '$apellidop', '$apellidom', $genero, '1', '1', '1', '$ingreso', '1');";
    

        return Executor::doit($sql);
    }

    public function setInscritoDob($matricula, $nombre, $apellidop, $apellidom, $dob, $genero, $anio){
        $ingreso = date('Y-m-d', strtotime($anio . "-08-01"));
        $sql = "INSERT INTO alumnos_inscritos (Matricula, Nombre, Apellido_p, Apellido_M,Dob ,Genero_fk, Carrera_fk, Nivel_fk, Facultad_fk, Fecha_Ingreso, Status  ) VALUES ('$matricula', '$nombre', '$apellidop', '$apellidom','$dob', $genero, '1', '1', '1', '$ingreso', '1');";
    

        return Executor::doit($sql);
    }

    public function verificacion($matricula){
        $sql = "SELECT count(Matricula) as numero FROM seguimiento_egresados2.alumnos_inscritos where Matricula='$matricula';";
        $result = Executor::doit($sql);
    
        if ($result[0] !== false && $result[0]->num_rows > 0) {

            $row = $result[0]->fetch_assoc();
            return $row['numero'];

        } else {
            return 0;
        }
    }

    public function UpdateAlumno($matricula,$carrera,$ingreso){
        $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Carrera_fk` = '$carrera', `Fecha_Ingreso` = '$ingreso-08-01'WHERE (`Matricula` = '$matricula');";
        return Executor::doit($sql);
    }

    
    public static function getDatos(){
        $sql = "SELECT * FROM inscritos2 order by Matricula;";
		$query = Executor::doit($sql);
		return Model::many($query[0], new Consultas());
    }
    
    public static function getAlumno($matricula){
        $sql = "SELECT * FROM seguimiento_egresados2.alumnos_inscritos where `Matricula` = '$matricula';";
		$query = Executor::doit($sql);
		return Model::one($query[0], new Consultas());
    }
    
}
