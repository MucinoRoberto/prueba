<?php

class Movilidades extends Extra{
    public static function VerificarDependencia($dependencia){
        try{
        $sql = "SELECT count(*) as count FROM seguimiento_egresados2.movilidades where Dependencia='$dependencia';";
		$query = Executor::doit($sql);
		return Model::one($query[0], new Consultas());
        }catch(Exception){
            return null;
        }

    }

    public function setMovilidad($dependencia,$pais){
        try{
        $sql = "INSERT INTO `seguimiento_egresados2`.`movilidades` (`Dependencia`, `Pais`) VALUES ('$dependencia',  '$pais');";
        return Executor::doit($sql);
        }catch(Exception){
            return null;
        }
    }

}