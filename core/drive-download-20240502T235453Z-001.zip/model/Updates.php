<?php
class Updates extends Extra
{

public function UpdateNombre($nombre,$matricula){
        $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Nombre` = '$nombre' WHERE (`Matricula` = '$matricula');";
        return Executor::doit($sql);
}

public function UpdateApellidoP($apellidoP,$matricula){
    $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Apellido_p` = '$apellidoP' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateApellidoM($apellidoM,$matricula){
    $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Apellido_m` = '$apellidoM' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateCarrera($matricula,$carrera){
    $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Carrera_fk` = '$carrera' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateIngreso($ingreso,$matricula){
    $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Fecha_Ingreso` = '$ingreso-08-01' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateEgreso($matricula,$egreso,$periodo){
    if ($periodo == 1) {
        $titulacion = date('Y-m-d', strtotime($egreso . "-01-31"));
    } else {
        $titulacion = date('Y-m-d', strtotime($egreso . "-07-31"));
    }

    $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Fecha_Egreso` = '$titulacion' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateTrabajo($matricula,$trabajo){

    $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET  `Primer_trabajo` = '$trabajo' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateMovilidad($matricula,$movilidad){

    $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET  `Movilidad_fk` = '$movilidad' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateArea($matricula,$area){

    $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Area_desarrollo_fk` = '$area' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdateDob($matricula,$dob){

    $sql = "UPDATE `seguimiento_egresados2`.`alumnos_inscritos` SET `Dob` = '$dob' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}

public function UpdatePeriodo($matricula,$periodo){

    $sql = "UPDATE `seguimiento_egresados2`.`egresados` SET `Periodo` = '$periodo' WHERE (`Matricula` = '$matricula');";
    return Executor::doit($sql);
}
}