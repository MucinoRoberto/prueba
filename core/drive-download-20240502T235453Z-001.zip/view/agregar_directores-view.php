<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="form-section">

            <h2>LLena los datos del Asesor</h2>
            <br>
            <form action="./?action=directores" method="post">
            <div class="row" style="display: none;">
                <div class="col">
                    <div class="form-floating" >
                        <input type="text" class="form-control" name="Num" id="Num" placeholder="" >
                        <label for="Num">Num de personal</label>
                    </div>
                </div>
                <br>
            </div>
            
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control"name="Nombre" id="Nombre" placeholder="S00000000" required>
                        <label for="Nombre">Nombre</label>
                    </div>
                    <br>
                </div>
                
            
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="ApellidoP" id="ApellidoP" placeholder="S00000000" >
                        <label for="ApellidoP">Apellido Paterno</label>
                    </div>
                    <br>
                </div>
            </div>
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="ApellidoM" id="ApellidoM" placeholder="S00000000" >
                        <label for="ApellidoM">Apellido Materno</label>
                    </div>
                    <br>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" onchange="Universidades()" value="" id="flexCheckChecked" checked>
                        <label class="form-check-label" for="flexCheckChecked">
                            Interno
                        </label>
                        <input type="hidden" id="interno" name="Interno" value="1">
                    </div>
                    <br>
                </div>
                <?php 
                $Universidades= Consultas::getUniversidades();?>
                
                    <div class="col-md-6"id="universidades" style="display: none;" >
                        <div class="form-floating">
                            <select  class="form-select"  id="Adscripcion" name="Adscripcion"  placeholder=""  >
                            <option value="" selected>...</option>
                                <?php foreach ($Universidades as $universidad) { ?>
                                <option value="<?php echo $universidad->Id_Universidad; ?>"><?php echo $universidad->Nombre_Universidad; ?></option>
                                <?php } ?>
                            </select>
                            <label for="Adscripcion">Adscripcion</label>
                        </div>
                    </div>
            </div>
            <div style="display: none;">
                <div class="row">
                <h6>Contactos: </h6>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="tel" class="form-control" placeholder="telefono" id="telefono" name="Telefono" >   
                            <label for="Telefono">Telefono:</label>
                        </div>
                        <br>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="email" class="form-control" placeholder="correo" id="Correo" name="Correo" >   
                            <label for="Correo">Correo:</label>
                        </div>
                        <br>
                    </div>
                    
                </div>
            </div>
            
            <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
        
        </form>
        <br>
        
    </div>
</div>
</div>
<script>

    function Universidades() {
            var checkbox = document.getElementById('flexCheckChecked');
            var div = document.getElementById('universidades');
            var interno = document.getElementById('interno');
            interno.value = checkbox.checked ? '1' : '0';

            if (checkbox.checked) {
                
                div.style.display = 'none';
            } else {
                
                div.style.display = 'block';
            }

        }

</script>