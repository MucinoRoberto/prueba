
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="form-section" >

        <h2>Llena los datos del egresado</h2>
        <br>
        <div class="row"></div>
        <form action="./?action=egresados&" method="post" >
                                
            <!-- Ingresar las Matriculas -->
            <?php 
            $Matriculas = Consultas::getMatriculas(); 
            ?>

            <div class="form-floating">
                <input  class="form-select" list="matriculas" name="matricula" id="matricula" placeholder="Busca la matricula..." required>
                <datalist id="matriculas" >
                    <?php foreach ($Matriculas as $matricula) { ?>
                    <option value="<?php echo $matricula->Matricula; ?>">
                    <?php } ?>
                </datalist>
                <label for="Matricula" class="form-label">Matricula</label>
                <br>
            </div>

            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="number" class="form-control" id="egreso"  name="egreso" placeholder="egreso" required>
                            <label for="egreso">Año de egreso</label>
                    </div>
                        <br>
                </div>

                <div class="col-md">
                    <div class="form-floating">
                        <select id="periodo" class="form-control"name="periodo" placeholder="Periodo" required>
                            <option value="0">...</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                        </select>
                        <label for="periodo" >Periodo:</label>
                    </div>
                    <br>
                </div>
            </div>
                
            <div class="row">
                <div class="col">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="trabajo"placeholder="Primer trabajo" name="trabajo" required>   
                        <label for="trabajo">Primer trabajo:</label>
                    </div>
                </div>
            </div>

            <br>

                <!-- titulaciones -->

            <div class="row">         
                <?php 
                    $Titulaciones = Consultas::getTitulaciones(); 
                ?>
                <div class="col-md-6">
                    <div class="form-floating">
                        <select  class="form-select"  id="Titulaciones"  onchange="titulacion()" name="Titulaciones" required placeholder="Busca la matricula...">
                            <option value="0" selected >Selecciona una opcion</option>
                                <?php foreach ($Titulaciones as $titulacion) { ?>
                            <option value="<?php echo $titulacion->Id_titulacion; ?>"><?php echo $titulacion->Nombre_titulacion; ?></option>
                                <?php } ?>
                        </select>
                        <label for="Titulaciones">Metodo de titulacion</label>
                        
                    </div>
                       <br>               
                </div>
                
                <div class="col-md-6">
                    <div name ="titulacion" id="pure"  style="display: block;">
                       <h6>Ingresa el modo de titulacion del egresado</h6>
                    </div>
                    <!-- Seleccionar el director de la tesis (esto se jalara desde la base de datos) -->   
                    <div id="dire" class="director" style="display: none;">
                        <?php 
                            $Directores = Consultas::getDirectores(); 
                        ?>
                        <div class="form-floating">
                            <select class="form-select" id="Director" onchange="coo()" name="Director" >
                                <option value="0" selected>Selecciona un director</option>
                                <?php foreach ($Directores as $director) { ?>
                                <option value="<?php echo $director->Id_director; ?>"><?php echo $director->Nombre; ?></option>
                                <?php } ?>
                            </select>
                            <label for="Director">Director de tesis:</label>
                        </div>    
                    </div>
                    <br>
                </div>
            </div>   
            <!-- seccion de coodirectores -->
            <div id="coodirector" style="display: none;" >
                <div class="row" >

                <!-- boton de coodirector1 -->
                <div class="col-md-6" id="botoncoodirector1" style="display: block;">
                <button type="button" onclick="coodirector1()" class="btn btn-outline-secondary"  id="agregarcorreo">Agregar Coodirector</button> 
                </div>
                
                <!-- coodirector1 -->
                <div class="col-md-6" id="coodirector1" style="display: none;"  >
                    <div class="form-floating" >
                        <select class="form-select" id="Coodirector" name="Coodirector1" >
                            <option value="0" selected>Selecciona un Coodirector</option>
                            <?php foreach ($Directores as $director) { ?>
                            <option value="<?php echo $director->Id_director; ?>"><?php echo $director->Nombre; ?></option>
                            <?php } ?>
                        </select>
                        <label for="Coodirector1">Coodirector de tesis:</label>
                    </div> 
                                    
                </div>
            
            </div>
            <br>
            </div>
            
            
            <!-- Seleccionar la movilidad (esto se jalara desde la base de datos) -->   
            <div class="row">
            <?php 
            $Movilidades = Consultas::getMovilidades(); 
            ?> 
            <div class="col-md-6">
            <div class="form-floating">
                <select class="form-select" aria-label="Disabled select example" id="Movilidad" name="Movilidad" required>
                    <option value="0" selected>Selecciona una opcion</option>
                    <?php foreach ($Movilidades as $movilidad) { ?>
                    <option value="<?php echo $movilidad->Id_movilidad; ?>"><?php echo $movilidad->Dependencia; ?></option>
                    <?php } ?>
                </select>
                <label for="Movilidad">Movilidad</label>
                <br>
            </div>
            </div>
         
            
            
            <!-- Seleccionar el area de desarrollo (esto se jalara desde la base de datos) --> 
            <?php   
            $Area = Consultas::getAreaDesarrollo(); 
            ?>  
            <div class="col-md-6">
            <div class="form-floating">
                <select class="form-select" aria-label="Disabled select example" id="area" name="area" required>
                    <option value="0" selected>Selecciona una opción</option>
                    <?php foreach ($Area as $area) { ?>
                    <option value="<?php echo $area->Id_area_desarrollo; ?>"><?php echo $area->Nombre_area; ?></option>
                    <?php } ?>
                </select>
                <label for="area">Área de desarrollo</label>
            </div>
            </div>
            </div>
            

            <h5>Contactos: </h5>
            <h6>Telefonos</h6>
            <div class="row">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="tel" class="form-control" placeholder="correo" id="telefono1" name="telefono1" pattern="[0-9]{10}" >   
                        <label for="telefono1">Número de teléfono:</label>
                    </div>
                </div>
                <div class="col-md">
                    <div class="form-floating">
                        <input type="tel" class="form-control" placeholder="correo" id="telefono2" name="telefono2" pattern="[0-9]{10}" >   
                        <label for="telefono2">Número de teléfono:</label>
                    </div>
                </div>
            </div>
            <small>Formato: 10 dígitos numéricos sin espacios ni guiones</small><br>
            <br>
            <h6>Correos: </h6>
            <div class="row">
                
                <div class="col-md">
                    <div class="form-floating">
                        <input type="email" class="form-control" placeholder="correo" id="Correo1" name="Correo1" >   
                        <label for="Correo1">Correo:</label>
                    </div>
                </div>
                <div class="col-md">
                    <div class="form-floating">
                        <input type="email" class="form-control" placeholder="correo" id="Correo2" name="Correo2" >   
                        <label for="Correo2">Correo:</label>
                    </div>
                </div>
            </div>
            <br>
            <div class="form-check">
                        <input class="form-check-input" type="checkbox" onchange="Posgrado()" id="flexCheckChecked" >
                        <label class="form-check-label" for="flexCheckChecked">
                            Posgrado
                        </label>
                        <input type="hidden" id="posgrado" name="posgrado" value="0">
                    </div>
            <br>
                
            </div>
                                        
            <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
        </form>
            <br>         
        </div>
    </div>
</div>
 <!-- script de javaScript para aparecer y desaparecer los div dependiendo de su metodo de titulacion -->
<script>
    var div = document.getElementById("dire");
    var div2= document.getElementById("pure"); 
    var div3=document.getElementById("coodirector");

    function Posgrado() {

            var checkbox = document.getElementById('flexCheckChecked');
            var posgrado = document.getElementById('posgrado');
            posgrado.value = checkbox.checked ? '1' : '0';

        }

    function titulacion() {
        let metodo = $("#Titulaciones").val();
        if (metodo == "1") {
            directores();
        } else {
            prom();
        }
    }

    
    function coo() {
        let metodo2 = $("#Director").val();
        if (metodo2 == "0") {
            div3.style.display = "none"; 
            document.getElementById("botoncoodirector1").style.display = "block";
            document.getElementById("coodirector1").style.display = "none"; 
        } else {
            div3.style.display = "block"; 
        }
    }

    
    
    function directores() { 
        div2.style.display = "none"; 
        div.style.display = "block";  
    }
    function coodirector1() { 
        document.getElementById("botoncoodirector1").style.display = "none";
        document.getElementById("coodirector1").style.display = "block"; 
    }
    
   
    function prom(){
        div.style.display = "none"; 
        div2.style.display = "block";  
        div3.style.display = "none";
    }

</script>
    

                   