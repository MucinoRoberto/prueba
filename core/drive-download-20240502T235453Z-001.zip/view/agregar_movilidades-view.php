<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="form-section">

            <h2>Ingresa la movilidad</h2>
            <br>
            <form action="./?action=movilidades&" method="post">
                <div class="row">
                    <?php 
                    $Movilidades = Consultas::getMovilidades(); 
                    ?>
                    <div class="col-md">
                        <small>Ingrese una dependencia diferente a las opciones</small>
                        <div class="form-floating">
                            <input  class="form-select" list="dependencias" name="dependencia" id="dependencia" placeholder="Ingrese una dependencia diferente a las opciones" required>
                                <datalist id="dependencias" >
                                    
                                    <?php foreach ($Movilidades as $movilidad) { ?>
                                    <option value="<?php echo $movilidad->Dependencia; ?>"></option>
                                    <?php } ?>
                                </datalist>
                            <label for="dependencia" class="form-label">Dependencia</label>
                        </div>
                        <br>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" class="form-control"name="Pais" id="Pais" placeholder="S00000000" >
                            <label for="Pais">País</label>
                        </div>
                        <br>
                    </div>
                </div>
                <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
            </form>
            <br>
            
        </div>
    </div>
</div>