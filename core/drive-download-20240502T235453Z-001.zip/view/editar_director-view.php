<div class="row justify-content-center">
    <div class="col-8">
<?php 
if(isset($_POST["opt"]) && $_POST["opt"] == "interno"){
   echo "maestro iterno";
   $Interno=Directores::getInterno($_POST['id']);
   ?>
   <form action="./?action=actualizar_interno&" method="get">
   <div class="row ">
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="Nombre" class="form-control" value="<?php echo $Interno->Nombre;?>" id="Nombre" placeholder="Name" >
                <label for="Nombre">Nombre:</label>
            </div>
        </div>
                
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoP" class="form-control" value="<?php echo $Interno->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                <label for="ApellidoP">Apellido Paterno:</label>
            </div>
        </div>
                        
    </div>
    <div class="row ">
        <div class="col-sm-6">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoM" class="form-control" value="<?php echo $Interno->Apellido_M;?>" id="apellidom" placeholder="Apellido">
                <label for="ApellidoM">Apellido Materno:</label>
            </div>
        </div>
      
        <?php 
                $Universidades= Consultas::getUniversidades();?>
                
                    <div class="col-md-6"id="universidades" style="display: none;" >
                        <div class="form-floating">
                            <select  class="form-select"  id="Adscripcion" name="Adscripcion"  placeholder=""  >
                            <option value="" selected>...</option>
                                <?php foreach ($Universidades as $universidad) { ?>
                                <option value="<?php echo $universidad->Id_Universidad; ?>"><?php echo $universidad->Nombre_Universidad; ?></option>
                                <?php } ?>
                            </select>
                            <label for="Adscripcion">Adscripcion</label>
                        </div>
                    </div>
          
        
    </div>
    
    <div class="row">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" onchange="Universidades()" value="" id="flexCheckChecked" checked>
                <label class="form-check-label" for="flexCheckChecked">
                Interno
                </label>
            <input type="hidden" id="interno" name="Interno" value="1">
        </div>
    </div>
    <br>
    <div class="row">
                <div class="col-sm">
                        <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
                </div>
         </div>
    </form>
   <?php
}else if(isset($_POST["opt"]) && $_POST["opt"] == "externo"){
    echo "maestro externo";
    $Externo=Directores::getExterno($_POST['id']);
    ?>
    <form action="./?action=actualizar_externo&" method="get">
    <div class="row ">
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="Nombre" class="form-control" value="<?php echo $Externo->Nombre;?>" id="Nombre" placeholder="Name" >
                <label for="Nombre">Nombre:</label>
            </div>
        </div>
                
        <div class="col-sm">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoP" class="form-control" value="<?php echo $Externo->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                <label for="ApellidoP">Apellido Paterno:</label>
            </div>
        </div>
                        
    </div>
    <div class="row ">
        <div class="col-sm-6">
            <div class="form-floating mb-3">
                <input type="text" name="ApellidoM" class="form-control" value="<?php echo $Externo->Apellido_M;?>" id="apellidom" placeholder="Apellido">
                <label for="ApellidoM">Apellido Materno:</label>
            </div>
        </div>
      
        <?php 
                $Universidades= Consultas::getUniversidades();?>
                
                    <div class="col-md-6"id="universidades" style="display: block;" >
                        <div class="form-floating">
                            <select  class="form-select"  id="Adscripcion" name="Adscripcion"  placeholder=""  >
                                <?php foreach ($Universidades as $universidad) {
                                    if($universidad->Id_Universidad==$Externo->Id_Universidad){ ?>
                                    
                                <option value="<?php echo $universidad->Id_Universidad; ?>" selected><?php echo $universidad->Nombre_Universidad; ?> </option>
                                <?php } else  {?>
                                    <option value="<?php echo $universidad->Id_Universidad; ?>" ><?php echo $universidad->Nombre_Universidad; ?> </option> 
                                    <?php
                                }
                               } ?>
                            </select>
                            <label for="Adscripcion">Adscripcion</label>
                        </div>
                    </div>
          
        
    </div>
    
    <div class="row">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" onchange="Universidades()" value="" id="flexCheckChecked" >
                <label class="form-check-label" for="flexCheckChecked">
                Interno
                </label>
            <input type="hidden" id="interno" name="Interno" value="0">
        </div>
    </div>
    <br>
    <div class="row">
                <div class="col-sm">
                        <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
                </div>
         </div>
    </form>
    <?php
 }?>

 <script>

function Universidades() {
        var checkbox = document.getElementById('flexCheckChecked');
        var div = document.getElementById('universidades');
        var interno = document.getElementById('interno');
        interno.value = checkbox.checked ? '1' : '0';

        if (checkbox.checked) {
            
            div.style.display = 'none';
        } else {
            
            div.style.display = 'block';
        }

    }

</script>