<div class="row justify-content-center">
    <div class="col-8">
<?php 
if(isset($_POST["opt"]) && $_POST["opt"] == "detail"){
        ?>

<?php $egresado=Egresados::getEgresado($_POST['matricula']);
if($egresado!=null){?>

     
     <div class="form-floating mb-3">
             <input type="text" name="Matricula" class="form-control" value="<?php echo $egresado->Matricula;?>" id="Matricula" placeholder="S00000000" disabled>
                     <label for="Matricula">Matricula:</label>
             </div>
          
              <div class="row ">
                      <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Nombre" class="form-control" value="<?php echo $egresado->Nombre;?>" id="Nombre" placeholder="Name" disabled>
                                     <label for="Nombre">Nombre:</label>
                             </div>
                              
                      </div>
                     
                      <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="ApellidoP" class="form-control" value="<?php echo $egresado->Apellido_p;?>" id="apellidop" placeholder="Apellido" disabled>
                                     <label for="ApellidoP">Apellido Paterno:</label>
                             </div>
                              
                      </div>
                             
              </div>
              <div class="row">
                     <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="ApellidoM" class="form-control" value="<?php echo $egresado->Apellido_M;?>" id="apellidom" placeholder="Apellido" disabled>
                                     <label for="ApellidoM">Apellido Materno:</label>
                             </div>
                              
                     </div>
                     <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Genero" class="form-control" value="<?php echo $egresado->Genero;?>" id="genero" placeholder="genero" disabled>
                                     <label for="Genero">Género:</label>
                             </div>
                              
                     </div>
             </div>
             <div class="row">
                <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="date" name="dob" class="form-control" value="<?php echo $egresado->Dob;?>" id="genero" placeholder="genero" disabled>
                                     <label for="dob">Fecha de nacimiento:</label>
                             </div>
                              
                     </div>
             </div>

             <div class="row ">        
                     <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Carrera" class="form-control" value="<?php echo $egresado->Nombre_carrera?>" id="carrera" placeholder="carrera" disabled>
                                     <label for="Carrera">Carrera:</label>
                             </div>
                              
                     </div>
                     <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Movilidad" class="form-control" value="<?php echo $egresado->Dependencia?>" id="carrera" placeholder="carrera" disabled>
                                     <label for="Carrera">Movilidad:</label>
                             </div>
                              
                     </div>
              </div>
              <div class="row">
                     <div class="col-sm-6">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Ingreso" class="form-control" value="<?php echo $egresado->ingreso?>" id="ingreso" placeholder="ingreso"disabled>
                                     <label for="Ingreso">Ingreso:</label>
                             </div>
                      </div>
                      <div class="col-sm-4">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Egreso" class="form-control" value="<?php echo $egresado->egreso?>" id="egreso" placeholder="egreso"disabled>
                                     <label for="Egreso">Egreso:</label>
                             </div>
                      </div>
                      <div class="col-sm-2">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Periodo" class="form-control" value="<?php echo $egresado->Periodo?>" id="egreso" placeholder="egreso"disabled>
                                     <label for="Periodo">Periodo:</label>
                             </div>
                      </div>
              </div>
              <div class="row">
                     <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="text" name="Titulacion" class="form-control" value="<?php echo $egresado->titulacion?>" id="titulacion" placeholder="titulacion" disabled>
                                     <label for="Titulacion">Modalidad de Titulación:</label>
                             </div>
                     </div>
              </div>
              <div class="row">
              <?php if( $egresado->Metodo_titulacion_fk==1) {?>
                      <?php $directores=Egresados::getDirectores($_POST['matricula']);
                      foreach ($directores as $director){
                              ?> 
                              
                              <div class="col-sm-6">
                                     <div class="form-floating mb-3">
                                             <input type="text" name="<?php echo $director->Tipo;?>" class="form-control" value="<?php echo $director->Nombre;?> <?php echo $director->Apellido_p;?> <?php echo $director->Apellido_M;?>" id="directores" placeholder="titulacion" disabled>
                                             <label for="<?php echo $director->Tipo;?>"> <?php echo $director->Tipo;?>:</label>
                                     </div>
                             </div>
                             <div class="col-sm-6">
                             
                                     <div class="form-floating mb-3">
                                        <?php if($director->Interno==0){?>
                                                <?php $externo=Directores::getExterno($director->Id_director);?>
                                                <input type="text" name="Dependencia" class="form-control" value="<?php echo $externo->Nombre_Universidad;?>" id="directores" placeholder="titulacion" disabled>
                                        <?php }else if($director->Interno==1){ ?>
                                                <input type="text" name="Dependencia" class="form-control" value="Interno" id="directores" placeholder="titulacion" disabled>
                                                <?php }?>
                                        <label for="Dependencia"> Dependencia:</label>
                                     </div>
                             </div>
                            
                              <?php
                      }?>
                      
                      </div>       
              <?php }?>
              <div class="row">
                     
                      <div class="col-sm">
                             
                             <div class="form-floating mb-3">
                                     <input type="text" name="Trabajo" class="form-control" value="<?php echo $egresado->Primer_trabajo; ?>" id="trabajo" placeholder="trabajo" disabled>
                                     <label for="Trabajo"> Primer trabajo:</label>
                             </div>
     
                      </div>
                     <div class="col-sm">
     
                             <div class="form-floating mb-3">
                                     <input type="text" name="Area" class="form-control" value="<?php echo $egresado->Nombre_area; ?>" id="area" placeholder="area"disabled>
                                     <label for="Area"> Area de desarrollo:</label>
                             </div>
      
                     </div>        
              </div>
              
              <div class="row">
                      <?php $telefonos=Egresados::getTelefonos($_POST['matricula'])?>
                      <?php $correos=Egresados::getCorreo($_POST['matricula'])?>
                      <div class="col">
                             <h5>
                             Contactos:
                             </h5>
                      </div>
             </div>
             <div class="row">
                              <?php foreach($telefonos as $telefono){?>
                             <div class="col-sm-6">
                                     <div class="form-floating mb-3">
                                             <input type="text" name="Telefono" class="form-control" value="<?php echo $telefono->Num_telefono;?>" id="tel" placeholder="tel" disabled>
                                             <label for="Telefono">Telefono:</label>
                                     </div>
                             </div>      
                             <?php } foreach($correos as $correo){?>
                             <div class="col-sm-6">
                                     <div class="form-floating mb-3">
                                             <input type="text" name="Correo" class="form-control" value="<?php echo $correo->Correo;?>" id="correo" placeholder="corero" disabled>
                                             <label for="Correo">Correo:</label>
                                     </div>
                             </div>         
                             <?php }?>
                      
              </div>
              
     
        
    
  <?php }else{
        echo "Hubo un problema";
  }  
}else if(isset($_POST["opt"]) && $_POST["opt"] == "edit"){



?>

 <?php $egresado=Egresados::getEgresado($_POST['matricula']);
 if($egresado!=null){?>
 
<form action="./?action=actualizar_egresados&" method="post">
<div class="form-floating mb-3">
        <input type="text" name="Matricula" class="form-control" value="<?php echo $egresado->Matricula;?>" id="Matricula" placeholder="S00000000" disabled>
                <label for="Matricula">Matricula:</label>
        </div>
        <input type="hidden" name="Matricula" class="form-control" value="<?php echo $egresado->Matricula;?>" id="Matricula" placeholder="S00000000" >
     
         <div class="row ">
                 <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="Nombre" class="form-control" value="<?php echo $egresado->Nombre;?>" id="Nombre" placeholder="Name" >
                                <label for="Nombre">Nombre:</label>
                        </div>
                         
                 </div>
                
                 <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="ApellidoP" class="form-control" value="<?php echo $egresado->Apellido_p;?>" id="apellidop" placeholder="Apellido">
                                <label for="ApellidoP">Apellido Paterno:</label>
                        </div>
                         
                 </div>
                        
         </div>
         <div class="row">
                <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="ApellidoM" class="form-control" value="<?php echo $egresado->Apellido_M;?>" id="apellidom" placeholder="Apellido">
                                <label for="ApellidoM">Apellido Materno:</label>
                        </div>
                         
                </div>
                <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="Genero" class="form-control" value="<?php echo $egresado->Genero;?>" id="genero" placeholder="genero" disabled>
                                <label for="Genero">Género:</label>
                        </div>
                         
                </div>
        </div>
        <div class="row">
                <div class="col-sm">
                             <div class="form-floating mb-3">
                                     <input type="date" name="dob" class="form-control" value="<?php echo $egresado->Dob;?>" id="genero" placeholder="genero" >
                                     <label for="dob">Fecha de nacimiento:</label>
                             </div>
                              
                     </div>
             </div>
        <div class="row ">    
                <?php   $Carreras = Consultas::getCarreras(); ?>      
                <div class="col-sm">
                        <div class="form-floating mb-3">
                                <select class="form-select" aria-label="Disabled select example" id="carrera" name="Carrera" required>
                                <?php foreach ($Carreras as $carrera) { if($carrera->Id_carrera==$egresado->Carrera_fk){?>
                                <option selected value="<?php echo $carrera->Id_carrera; ?>"><?php echo $carrera->Nombre_carrera ?></option><?php }else{?>
                                <option  value="<?php echo $carrera->Id_carrera; ?>"><?php echo $carrera->Nombre_carrera ?>  </option>     
                                <?php } ?>
                                <?php } ?>
                                </select>
                                <label for="movilidad">Carrera</label>
                        </div>
                         
                </div>
                <?php   $Movidades = Consultas::getMovilidades(); ?>  
                <div class="col-sm">
                        <div class="form-floating">
                                <select class="form-select" aria-label="Disabled select example" id="movilidad" name="movilidad" required>
                                <?php foreach ($Movidades as $movilidad) { if($movilidad->Dependencia==$egresado->Dependencia){?>
                                <option selected value="<?php echo $movilidad->Id_movilidad; ?>"><?php echo$movilidad->Dependencia ?></option><?php }else{?>
                                <option  value="<?php echo $movilidad->Id_movilidad; ?>"><?php echo $movilidad->Dependencia ?>  </option>     
                                <?php } ?>
                                <?php } ?>
                                </select>
                                <label for="movilidad">Movilidad</label>
                        </div>    
                </div>   
         </div>
         <div class="row">
                <div class="col-sm-6">
                        <div class="form-floating mb-3">
                                <input type="text" name="Ingreso" class="form-control" value="<?php echo $egresado->ingreso?>" id="ingreso" placeholder="ingreso">
                                <label for="Ingreso">Ingreso:</label>
                        </div>
                 </div>
                 <div class="col-sm-4">
                        <div class="form-floating mb-3">
                                <input type="text" name="Egreso" class="form-control" value="<?php echo $egresado->egreso?>" id="egreso" placeholder="egreso">
                                <label for="Egreso">Egreso:</label>
                        </div>
                </div>
                <div class="col-sm-2">
                        <div class="form-floating">
                                <select  class="form-select"  id="periodo" name="periodo"  >
                                
                                <?php if ($egresado->Periodo==1) { ?>
                                <option selected value="1">1</option>
                                <option value="2">2</option>
                                <?php } else{ ?>
                                <option  value="1">1</option>
                                <option selected value="2">2</option>
                                <?php } ?>
                                </select>
                                <label for="periodo">Periodo:</label>
                        </div>
                 </div>
         </div>
         <div class="row">
                <div class="col-sm">
                        <div class="form-floating mb-3">
                                <input type="text" name="Titulacion" class="form-control" value="<?php echo $egresado->titulacion?>" id="titulacion" placeholder="titulacion" disabled>
                                <label for="Titulacion">Modalidad de Titulación:</label>
                        </div>
                </div>
         </div>
         <div class="row">
         <?php
                if ($egresado->Metodo_titulacion_fk == 1) {
                $directores = Egresados::getDirectores($_POST['matricula']);
                $countdirec = Egresados::getCountDirectores($_POST['matricula']);
                $direc = Consultas::getDirectores();
                $contador3 = 1;

                if ($countdirec->count == 2) {
                        foreach ($directores as $director) { 
                ?>
                                <div class="col-sm-6">
                                        <div class="form-floating">
                                                <select class="form-select" aria-label="Disabled select example" id="director" name="director<?php echo $contador3; ?>" required>
                                                        <?php foreach ($direc as $area) { 
                                                                if ($area->Id_director == $director->Id_director) { ?>
                                                                        <option selected value="<?php echo $area->Id_director; ?>"><?php echo $area->Nombre; ?></option>
                                                                <?php } else { ?>
                                                                        <option value="<?php echo $area->Id_director; ?>"><?php echo $area->Nombre; ?></option>
                                                                <?php } ?>
                                                        <?php } ?>
                                                </select>
                                        <label for="area"><?php echo $director->Tipo; ?></label>
                                        <br>
                                        </div>
                                </div>
                <?php
                        $contador3 = $contador3 + 1;
                        }
                }else{
                        foreach ($directores as $director) {  ?>
                                <div class="col-sm-6">
                                        <div class="form-floating">
                                                <select class="form-select" aria-label="Disabled select example" id="director" name="director<?php echo $contador3; ?>" required>
                                                        <?php foreach ($direc as $area) { 
                                                                if ($area->Id_director == $director->Id_director) { ?>
                                                                        <option selected value="<?php echo $area->Id_director; ?>"><?php echo $area->Nombre;?> <?php echo $area->Apellido_p;?> <?php echo $area->Apellido_M; ?></option>
                                                                <?php } else { ?>
                                                                        <option value="<?php echo $area->Id_director; ?>"><?php echo $area->Nombre;?> <?php echo $area->Apellido_p; ?> <?php echo $area->Apellido_M;?></option>
                                                                <?php } ?>
                                                        <?php } ?>
                                                </select>
                                                <label for="area"><?php echo $director->Tipo; ?></label>
                                                <br>
                                        </div>
                                </div>
                                <?php
                                $contador3 = $contador3 + 1;
                        }
                                ?>
                        
                                        <?php
                }
                ?>
                <br>

                <?php
        }
                ?>
                
         </div>
         
        <div class="row">
                
                 <div class="col-sm">
                        
                        <div class="form-floating mb-3">
                                <input type="text" name="Trabajo" class="form-control" value="<?php echo $egresado->Primer_trabajo; ?>" id="trabajo" placeholder="trabajo">
                                <label for="Trabajo"> Primer trabajo:</label>
                        </div>

                 </div>
                 <?php   $Area = Consultas::getAreaDesarrollo(); ?>  
                 <div class="col-sm">
                        <div class="form-floating">
                                <select class="form-select" aria-label="Disabled select example" id="area" name="area" required>
                                <?php foreach ($Area as $area) { if($area->Nombre_area==$egresado->Nombre_area){?>
                                <option selected value="<?php echo $area->Id_area_desarrollo; ?>"><?php echo $area->Nombre_area; ?></option><?php }else{?>
                                <option  value="<?php echo $area->Id_area_desarrollo; ?>"><?php echo $area->Nombre_area; ?>       
                                <?php } ?>
                                <?php } ?>
                                </select>
                                <label for="area">Área de desarrollo</label>
                        </div>    
                </div>   
        </div>
         
         <div class="row">
                <?php $telefonos=Egresados::getTelefonos($_POST['matricula']);
                $correos=Egresados::getCorreo($_POST['matricula']);
                $totaltelefonos=Egresados::getTotalTelefonos($_POST['matricula']);
                $totalcorreos=Egresados::getTotalCorreos($_POST['matricula']);?>
                 <div class="col">
                        <h5>
                        Contactos: <br>

                        </h5>
                 </div>
        </div>

        <div class="row">

        <small>Formato: 10 dígitos numéricos sin espacios ni guiones</small><br>
                <?php  $contador=1; 
                foreach($telefonos as $telefono){ ?>
                       
                        <div class="col-sm-6">
                                <div class="form-floating mb-3">
                                <input type="text" pattern="[0-9]{10}" name="Telefono<?php echo $contador?>" class="form-control" value="<?php echo $telefono->Num_telefono; ?>" placeholder="tel">
                                <label for="Telefono">Telefono:</label>
                                </div>
                        </div>    
                        <input type="hidden" name="idtelefonoviejo<?php echo $contador?>" class="form-control" value="<?php echo $telefono->Id_telefono; ?>" >  
                        <input type="hidden" name="telefonoviejo<?php echo $contador?>" class="form-control" value="<?php echo $telefono->Num_telefono; ?>" id="telefonoviejo" placeholder="S00000000" >  
                        <?php $contador=$contador+1;
                } ?>
                <?php
                if($totaltelefonos->total==1){
                        ?>
                        <div class="col-sm-6" id="botontelefono">
                                <button type="button" class="btn btn-outline-secondary" onclick="AgregarTelefono()" id="agregartelefono">Agregar Telefono</button>  
                                <br>
                        </div>
                <?php } ?>
                <?php
                if($totaltelefonos->total==0){
                        ?>
                        <div class="col-sm-6" id="botontelefono1" >
                                <button type="button" class="btn btn-outline-secondary" onclick="AgregarTelefono1()" id="agregartelefono">Agregar Telefono</button>  
                                <br>
                        </div>
                <?php } ?>
        
                <div class="col-sm-6" id="telefononuevo1" style="display: none;">
                        <div class="form-floating mb-3">
                        <input type="text" name="TelefonoNuevo1"  pattern="[0-9]{10}" class="form-control"  placeholder="tel">
                        <label for="TelefonoNuevo1">Telefono:</label>
                        </div>
                </div>

                <div class="col-sm-6" id="botontelefono2" style="display: none;">
                        <button type="button" class="btn btn-outline-secondary" onclick="AgregarTelefono()" id="agregartelefono">Agregar Telefono</button>  
                        <br>
                </div>

                <div class="col-sm-6" id="telefononuevo2" style="display: none;">
                        <div class="form-floating mb-3">
                                <input type="text" name="TelefonoNuevo2" pattern="[0-9]{10}" class="form-control"  placeholder="tel">
                                <label for="TelefonoNuevo2">Telefono:</label>
                        </div>
                </div>

        </div>
        <p></p>
        <div class="row">
                <?php $contador2=1;
                 foreach($correos as $correo){ ?>
                        <div class="col-sm-6">
                                <div class="form-floating mb-3">
                                <input type="email" name="Correo<?php echo $contador2;?>" class="form-control" value="<?php echo $correo->Correo; ?>" placeholder="correo">
                                <label for="Correo">Correo:</label>
                                <input type="hidden" name="correoviejo<?php echo $contador2;?>" class="form-control" value="<?php echo $correo->Correo; ?>" >
                                <input type="hidden" name="idcorreoviejo<?php echo $contador2;?>" class="form-control" value="<?php echo $correo->Id_correos; ?>" >
                                </div>
                        </div>         
                        <?php $contador2=$contador2+1;
                 } 
                
                if($totalcorreos->total==0){?>
                        <div class="col-sm-6" id="botoncorreo1">
                                <button type="button" class="btn btn-outline-secondary" onclick="AgregarCorreo1()" id="agregarcorreo">Agregar Correo</button>  
                                <br>
                        </div> 
                        <?php
                } if($totalcorreos->total==1){?>
                        <div class="col-sm-6" id="botoncorreo">
                                <button type="button" class="btn btn-outline-secondary" onclick="AgregarCorreo()" id="agregarcorreo">Agregar Correo</button>  
                                <br>
                        </div> 
                        <?php
                }
                ?>
                <div class="col-sm-6" id="correonuevo1" style="display: none;">
                        <div class="form-floating mb-3">
                                <input type="email" name="CorreoNuevo1" class="form-control"  placeholder="correo">
                                <label for="CorreoNuevo1">Correo:</label>
                        </div>
                </div>
                <div class="col-sm-6" id="botoncorreo2" style="display: none;">
                        <button type="button" class="btn btn-outline-secondary" onclick="AgregarCorreo()" id="agregarcorreo">Agregar Correo</button>  
                        <br>
                </div> 
                <div class="col-sm-6" id="correonuevo2" style="display: none;">
                        <div class="form-floating mb-3">
                                <input type="email" name="CorreoNuevo2" class="form-control"  placeholder="correo">
                                <label for="CorreoNuevo2">Correo:</label>
                        </div>
                </div>
        </div>
        
        <br>       
        

        <div class="row">
                <div class="col-sm">
                        <button class="btn btn-outline-secondary" type="submit" id="inputGroupFileAddon03">Enviar</button>
                </div>
         </div>
         
         </form>
         <br>

<?php
 }else{
        echo "hubo un problema";
 }
}
?>
<script>

    function AgregarCorreo() { 
        document.getElementById("correonuevo2").style.display = "block";
        document.getElementById("botoncorreo2").style.display = "none";
        document.getElementById("botoncorreo").style.display = "none";
        
    }

    function AgregarCorreo1() { 
        document.getElementById("correonuevo1").style.display = "block";  
        document.getElementById("botoncorreo1").style.display = "none";
        document.getElementById("botoncorreo2").style.display = "block";
        
    }
    
    function AgregarTelefono1(){
        document.getElementById("telefononuevo1").style.display = "block";  
        document.getElementById("botontelefono1").style.display = "none";
        document.getElementById("botontelefono2").style.display = "block";
    }
    function AgregarTelefono(){
        document.getElementById("telefononuevo2").style.display = "block";
        document.getElementById("botontelefono2").style.display = "none";
        document.getElementById("botontelefono").style.display = "none";
    }
</script>
