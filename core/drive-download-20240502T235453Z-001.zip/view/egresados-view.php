<style>
    .form-scetion{
        overflow: auto;
    }
</style>
<div class="form-scetion">
    <div class="col">
        
<table class="table">
  <thead>
    <tr  class="table-light">
      <th scope="col">Matricula</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido Paterno</th>
      <th scope="col">Apellido Materno</th>
      <th scope="col">Año ingreso</th>
      <th scope="col">Movilidad</th>
      <th scope="col">Año egreso</th>
      <th scope="col">Titulación</th>
      <th scope="col"></th>
      
    </tr>
  </thead>
  <tbody>
    <?php 
  
        $alumnos = Egresados::getDatos(); 
    ?>
    <?php foreach ($alumnos as $alumno) { ?>
    
    <tr >
      <th scope="row" class="table-light" ><?php echo $alumno->Matricula ?></th>
      <td class="table-secondary"><?php echo $alumno->Nombre ?></td>
      <td class="table-light"><?php echo $alumno->Apellido_p ?></td>
      <td class="table-secondary"><?php echo $alumno->Apellido_M ?></td>
      <td class="table-light"><?php echo $alumno->ingreso ?></td>
      <td class="table-secondary"><?php echo $alumno->Dependencia ?></td>
      <td class="table-light"><?php echo $alumno-> egreso?></td>
      <td class="table-secondary"><?php echo $alumno->titulacion ?></td>
      <td class="table-light">

      <div class="col">
        <div style="display: flex;">
            <form action="./?view=editar_egresado&" method="post" style="margin-right: 10px;">     
                <input type="hidden" name="opt" value="edit">
                <input type="hidden" name="matricula" value="<?php echo $alumno->Matricula ?>">
                <button class="btn btn-primary" type="submit" data-bs-toggle="tooltip" title="Editar datos de <?php echo $alumno->Matricula ?>">
                    <svg xmlns="http://www.w3.org/2000/svg"  href="?view=agregar_inscritos" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                    </svg>
                </button>
            </form>

            <form action="./?view=editar_egresado&" method="post">
                <input type="hidden" name="opt" value="detail">
                <input type="hidden" name="matricula" value="<?php echo $alumno->Matricula ?>">
                <button class="btn btn-success" type="submit" data-bs-toggle="tooltip" title="Detalles de <?php echo $alumno->Matricula ?>">
                    <svg xmlns="http://www.w3.org/2000/svg"  width="16" height="16" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
                        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
                    </svg>
                </button>
            </form>
        </div>
    </div>

       
        
      </td>
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>
</div>
