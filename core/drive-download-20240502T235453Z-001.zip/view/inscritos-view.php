<style>
    .form-scetion{
        overflow: auto;
    }
</style>
<div class="form-scetion">
<table class="table">
  <thead>
    <tr >
      <th scope="col">Matricula</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido Paterno</th>
      <th scope="col">Apellido Materno</th>
      <th scope="col">Genero</th>
      <th scope="col">Carrera</th>
      <th scope="col">Año ingreso</th>
    </tr>
  </thead>
  <tbody>
    <?php 
  
        $alumnos = Inscritos::getDatos(); 
    ?>
    <?php foreach ($alumnos as $alumno) { ?>
    
    <tr >
      <th scope="row" class="table-light" ><?php echo $alumno->Matricula ?></th>
      <td class="table-secondary"><?php echo $alumno->Nombre ?></td>
      <td class="table-light"><?php echo $alumno->Apellido_p ?></td>
      <td class="table-secondary"><?php echo $alumno->Apellido_M ?></td>
      <td class="table-light"><?php echo $alumno->Genero ?></td>
      <td class="table-secondary"><?php echo $alumno->Nombre_carrera ?></td>
      <td class="table-light"><?php echo $alumno-> fecha?></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>
