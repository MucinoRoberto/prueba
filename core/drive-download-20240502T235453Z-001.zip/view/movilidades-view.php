<table class="table">
  <thead>
    <tr>
      <th scope="col">Dependencia</th>
      <th scope="col">Pais</th>
    </tr>
  </thead>
  <?php $Movilidades=Consultas::getMovilidades();?>
  <tbody>
    <?php foreach($Movilidades as $movilidad){?>
    <tr>
      <th scope="row"  class="table-light"><?php echo $movilidad->Dependencia?></th>
      <td class="table-secondary"><?php echo $movilidad->Pais?></td>
     
    </tr>
    <?php }?>
  </tbody>
</table>